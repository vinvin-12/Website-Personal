<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<style>
  body {
    font-family: 'Inter', 'Segoe UI', sans-serif;
    background-color: #f9fafb;
    color: #1f2937;
  }

  h2 {
    font-weight: 700;
    font-size: 1.5rem;
    color: #111827;
    margin-bottom: 1.25rem;
  }

  .table-wrapper {
    background-color: #ffffff;
    padding: 2rem;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);
    transition: box-shadow 0.3s ease;
  }

  .table-wrapper:hover {
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.08);
  }

  .table th {
    background-color: #f3f4f6 !important;
    text-align: center;
    vertical-align: middle;
    font-weight: 600;
    color: #374151;
    font-size: 0.95rem;
  }

  .table td {
    vertical-align: middle;
    text-align: center;
    font-size: 0.94rem;
    color: #4b5563;
    padding: 0.75rem;
    border-color: #e5e7eb;
  }

  .text-start {
    text-align: left !important;
  }

  .btn {
    border-radius: 8px;
    font-weight: 600;
    padding: 0.5rem 1.1rem;
    font-size: 0.92rem;
    transition: background-color 0.2s ease, box-shadow 0.2s ease;
  }

  .btn-primary {
    background-color: #3b82f6;
    border: none;
    color: white;
  }

  .btn-primary:hover {
    background-color: #2563eb;
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
  }

  .btn-danger {
    background-color: #ef4444;
    border: none;
    color: white;
  }

  .btn-danger:hover {
    background-color: #dc2626;
    box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
  }

  .math-block {
    background: #f1f5f9;
    padding: 1rem 1.5rem;
    border-left: 4px solid #3b82f6;
    border-radius: 8px;
    font-family: 'Fira Code', monospace;
    font-size: 0.95rem;
    color: #374151;
    margin-bottom: 1.5rem;
  }

  ul li {
    margin-bottom: 0.5rem;
    font-size: 0.94rem;
    color: #374151;
  }

  .text-muted {
    color: #9ca3af !important;
  }

  .table-responsive {
    overflow-x: auto;
  }
</style>

<div class="container mt-5">
  <div class="table-wrapper">
    <h2>📐 Normalisasi Matriks</h2>

    <div class="table-responsive">
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>No</th>
            <th>Kode Daging</th>
            <th>Jenis Daging</th>
            <?php foreach ($kriteria as $nama_kriteria): ?>
              <th><?= esc($nama_kriteria); ?></th>
            <?php endforeach; ?>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; ?>
          <?php if (!empty($normalisasi)): ?>
            <?php foreach ($normalisasi as $id_daging => $row): ?>
              <tr>
                <td><?= $no++; ?></td>
                <td><?= esc($row['kode_daging']); ?></td>
                <td class="text-start"><?= esc($row['jenis_daging']); ?></td>
                <?php foreach ($kriteria as $id_kriteria => $nama): ?>
                  <td><?= isset($row['nilai'][$id_kriteria]) ? number_format($row['nilai'][$id_kriteria], 4) : '0.0000'; ?></td>
                <?php endforeach; ?>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="<?= 3 + count($kriteria); ?>" class="text-center text-muted">Data belum dihitung.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <div class="mb-3">
      <form action="<?= base_url('normalisasi/hitung'); ?>" method="post" style="display: inline-block;">
        <?= csrf_field(); ?>
        <button type="submit" class="btn btn-primary">Hitung Normalisasi</button>
      </form>

      <form action="<?= base_url('normalisasi/hapussemua'); ?>" method="post" style="display: inline-block;" onsubmit="return confirm('Yakin ingin menghapus semua data?');">
        <?= csrf_field(); ?>
        <button type="submit" class="btn btn-danger">Hapus Semua</button>
      </form>
    </div>
  </div>
</div>

<!-- Keterangan Rumus -->
<div class="container mt-4">
  <div class="table-wrapper">
    <h2>📘 Keterangan</h2>
    <p><strong>Rumus Normalisasi:</strong></p>

    <div class="math-block">
      r = x / √(∑x²)
    </div>

    <p>Dengan:</p>
    <ul>
      <li><strong>r</strong> = nilai matriks ternormalisasi</li>
      <li><strong>x</strong> = nilai dari penilaian</li>
      <li><strong>∑x²</strong> = total kuadrat dari semua nilai untuk kriteria terkait</li>
    </ul>
  </div>
</div>

<?= $this->endSection(); ?>
