<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<style>
    .custom-badge-terpilih {
        display: inline-block;
        padding: 0.4rem 0.75rem;
        font-size: 0.85rem;
        font-weight: 600;
        color: #fff;
        background-color: #198754;
        border-radius: 0.5rem;
    }

    .custom-badge-default {
        display: inline-block;
        padding: 0.4rem 0.75rem;
        font-size: 0.85rem;
        font-weight: 500;
        color: #6c757d;
        background-color: #f1f3f5;
        border-radius: 0.5rem;
    }

    h2 {
        font-weight: 700;
        color: #212529;
    }

    .table thead th {
        background-color: #f8f9fa;
        color: #343a40;
        text-transform: uppercase;
        font-size: 0.85rem;
        border-bottom: 2px solid #dee2e6;
    }

    .table td, .table th {
        vertical-align: middle;
        font-size: 0.95rem;
        padding: 0.75rem;
    }

    .btn-success {
        font-weight: 500;
        padding: 0.5rem 1.5rem;
        border-radius: 2rem;
        transition: all 0.3s ease-in-out;
    }

    .btn-success:hover {
        background-color: #157347;
        border-color: #157347;
    }

    .card-table {
        background-color: #ffffff;
        border-radius: 1rem;
        padding: 2rem;
        box-shadow: 0 0 1rem rgba(0, 0, 0, 0.05);
    }

    .table-striped > tbody > tr:nth-of-type(odd) {
        background-color: #f8f9fa;
    }

    .text-end {
        margin-top: 1.5rem;
    }
</style>

<div class="container mt-5">
    <h2 class="text-center mb-4">Hasil Daging Ayam Terbaik</h2>

    <!-- Tabel Data Nilai Akhir -->
    <div class="container mt-4">
        <div class="card-table">
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle mb-0">
                    <thead>
                        <tr class="text-center">
                            <th>Jenis Daging Ayam</th>
                            <th>Nilai Akhir</th>
                            <th>Ranking</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ranking as $i => $row): ?>
                        <tr class="text-center <?= $i === 0 ? 'table-success' : '' ?>">
                            <td class="text-start"><?= esc($row['jenis_daging']) ?></td>
                            <td><?= number_format($row['total'], 4) ?></td>
                            <td><strong><?= $i + 1 ?></strong></td>
                            <td>
                                <?php if ($i == 0): ?>
                                    <span class="custom-badge-terpilih">Terpilih</span>
                                <?php else: ?>
                                    <span class="custom-badge-default">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="text-end">
                <a href="<?= base_url('nilaiakhir/cetakpdf'); ?>" class="btn btn-success" target="_blank">
                    <i class="bi bi-printer me-1"></i> Cetak Data
                </a>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>
