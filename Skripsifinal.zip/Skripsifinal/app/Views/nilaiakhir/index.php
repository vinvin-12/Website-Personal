<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<style>
  body {
    font-family: 'Inter', 'Segoe UI', sans-serif;
    background-color: #f9fafb;
    color: #1f2937;
  }

  h2, h4 {
    font-weight: 700;
    color: #111827;
    margin-bottom: 1.25rem;
  }

  .table-wrapper {
    background: #ffffff;
    padding: 2rem;
    border-radius: 16px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.05);
    transition: box-shadow 0.3s ease;
  }

  .table-wrapper:hover {
    box-shadow: 0 12px 32px rgba(0, 0, 0, 0.08);
  }

  .table th {
    background-color: #f3f4f6 !important;
    text-align: center;
    vertical-align: middle;
    font-weight: 600;
    font-size: 0.95rem;
    color: #374151;
  }

  .table td {
    vertical-align: middle;
    text-align: center;
    font-size: 0.94rem;
    color: #4b5563;
    padding: 0.75rem;
    border-color: #e5e7eb;
  }

  .text-start {
    text-align: left !important;
  }

  .btn {
    border-radius: 8px;
    font-weight: 600;
    padding: 0.5rem 1.1rem;
    font-size: 0.92rem;
    transition: background-color 0.2s ease, box-shadow 0.2s ease;
  }

  .btn-primary {
    background-color: #3b82f6;
    border: none;
    color: white;
  }

  .btn-primary:hover {
    background-color: #2563eb;
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
  }

  .btn-danger {
    background-color: #ef4444;
    border: none;
    color: white;
  }

  .btn-danger:hover {
    background-color: #dc2626;
    box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
  }

  .btn-success {
    background-color: #10b981;
    border: none;
    color: white;
  }

  .btn-success:hover {
    background-color: #059669;
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
  }

  .btn + .btn {
    margin-left: 0.75rem;
  }

  .custom-badge-terpilih {
    background-color: #22c55e;
    color: #fff;
    padding: 0.3rem 0.7rem;
    border-radius: 6px;
    font-size: 0.85rem;
    font-weight: 500;
  }

  .custom-badge-default {
    background-color: #e2e8f0;
    color: #475569;
    padding: 0.3rem 0.7rem;
    border-radius: 6px;
    font-size: 0.85rem;
    font-weight: 500;
  }

  .math-block {
    background: #f9fafb;
    padding: 1rem 1.5rem;
    border-left: 4px solid #3b82f6;
    border-radius: 8px;
    font-family: 'Fira Code', monospace;
    font-size: 0.95rem;
    color: #374151;
    margin-bottom: 1.5rem;
  }

  ul li {
    margin-bottom: 0.5rem;
    font-size: 0.94rem;
    color: #374151;
  }

  .text-muted {
    color: #9ca3af !important;
  }

  .table-responsive {
    overflow-x: auto;
  }
</style>

<div class="container mt-5">
  <div class="table-wrapper">
    <h2>📊 Data Nilai Akhir</h2>

    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>No</th>
          <th>Kode Daging</th>
          <th>Jenis Daging</th>
          <?php foreach ($kriteria as $nama_kriteria): ?>
            <th><?= esc($nama_kriteria); ?></th>
          <?php endforeach; ?>
          <th>Total Skor Akhir</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($nilai_akhir)): ?>
          <?php $no = 1; ?>
          <?php foreach ($nilai_akhir as $n): ?>
            <tr>
              <td><?= $no++; ?></td>
              <td><?= esc($n['kode_daging']); ?></td>
              <td class="text-start"><?= esc($n['jenis_daging']); ?></td>
              <?php foreach ($kriteria as $id_kriteria => $nama_kriteria): ?>
                <td><?= isset($n['nilai'][$id_kriteria]) ? number_format($n['nilai'][$id_kriteria], 3) : '0.000'; ?></td>
              <?php endforeach; ?>
              <td><strong><?= number_format($n['total'], 3); ?></strong></td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="<?= 5 + count($kriteria); ?>" class="text-center text-muted">
              Data nilai akhir belum dihitung. Silakan klik tombol <strong>"Hitung Nilai Akhir"</strong>.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>

    <div class="mb-3 mt-3">
      <form action="<?= base_url('nilaiakhir/hitung'); ?>" method="post" style="display: inline-block;">
        <?= csrf_field(); ?>
        <button type="submit" class="btn btn-primary">Hitung Nilai Akhir</button>
      </form>

      <form action="<?= base_url('nilaiakhir/hapussemua'); ?>" method="post" style="display: inline-block;" onsubmit="return confirm('Yakin ingin menghapus semua data nilai akhir?');">
        <?= csrf_field(); ?>
        <button type="submit" class="btn btn-danger">Hapus Semua Nilai Akhir</button>
      </form>
    </div>
  </div>
</div>

<!-- Tabel Top 3 -->
<div class="container mt-4">
  <div class="table-wrapper">
    <h4>🏆 Hasil Akhir Daging Ayam Terbaik</h4>
    <div class="table-responsive">
      <table class="table table-striped mb-3">
        <thead>
          <tr>
            <th>Jenis Daging</th>
            <th>Nilai Akhir</th>
            <th>Ranking</th>
            <th>Keterangan</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($ranking as $i => $row): ?>
            <tr>
              <td><?= esc($row['jenis_daging']) ?></td>
              <td><?= number_format($row['total'], 4) ?></td>
              <td><?= $i + 1 ?></td>
              <td>
                <?php if ($i == 0): ?>
                  <span class="custom-badge-terpilih">Terpilih</span>
                <?php else: ?>
                  <span class="custom-badge-default">-</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <a href="<?= base_url('nilaiakhir/cetakpdf'); ?>" class="btn btn-success" target="_blank">Cetak Data</a>
    </div>
  </div>
</div>

<!-- Keterangan Rumus -->
<div class="container mt-4">
  <div class="table-wrapper">
    <h2>📘 Keterangan</h2>
    <p><strong>Rumus perhitungan nilai akhir:</strong></p>

    <div class="math-block">
      Skor = ∑<sub>i=1</sub><sup>n</sup> (u<sub>i</sub> × w<sub>i</sub>)
    </div>

    <p><strong>Keterangan:</strong></p>
    <ul>
      <li><strong>Skor</strong>: Nilai akhir untuk setiap supplier</li>
      <li><strong>u<sub>i</sub></strong>: Nilai utility untuk kriteria ke-i</li>
      <li><strong>w<sub>i</sub></strong>: Bobot yang telah dinormalisasi untuk kriteria ke-i</li>
      <li><strong>∑</strong>: Penjumlahan dari seluruh kriteria</li>
    </ul>
  </div>
</div>

<?= $this->endSection(); ?>
