<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<!-- Modern & Elegant Styling -->
<style>
  body {
    font-family: 'Inter', 'Segoe UI', sans-serif;
    background-color: #f1f5f9;
    color: #1e293b;
    margin: 0;
  }

  h2 {
    font-weight: 700;
    color: #0f172a;
    margin-bottom: 1.5rem;
    font-size: 1.5rem;
  }

  .container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
  }

  .table-wrapper {
    background-color: #ffffff;
    padding: 2rem;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.04);
    transition: all 0.3s ease-in-out;
  }

  .table-wrapper:hover {
    box-shadow: 0 12px 24px rgba(0, 0, 0, 0.06);
  }

  .table th {
    background-color: #e2e8f0 !important;
    color: #1e293b;
    font-weight: 600;
    text-align: center;
    vertical-align: middle;
  }

  .table td {
    vertical-align: middle;
    text-align: center;
    font-size: 0.95rem;
  }

  .table td.text-start {
    text-align: left;
  }

  .btn {
    border-radius: 8px;
    font-weight: 600;
    padding: 0.5rem 1.2rem;
    font-size: 0.9rem;
    margin-top: 1rem;
    transition: all 0.2s ease-in-out;
  }

  .btn-primary {
    background-color: #2563eb;
    border: none;
    color: #ffffff;
  }

  .btn-primary:hover {
    background-color: #1d4ed8;
  }

  .btn-danger {
    background-color: #dc2626;
    border: none;
    color: #ffffff;
  }

  .btn-danger:hover {
    background-color: #b91c1c;
  }

  .math-box {
    background: #f8fafc;
    border-left: 5px solid #2563eb;
    padding: 1rem 1.5rem;
    border-radius: 8px;
    font-family: 'Courier New', monospace;
    font-size: 1rem;
    color: #1e293b;
    margin-bottom: 1rem;
  }

  ul li {
    margin-bottom: 0.5rem;
    font-size: 0.95rem;
  }

  .mb-3 form {
    margin-right: 1rem;
  }
</style>

<!-- Tampilan Utama -->
<div class="container mt-5">
  <div class="table-wrapper">
    <h2>📊 Normalisasi Matriks Terbobot</h2>

    <div class="table-responsive">
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>No</th>
            <th>Kode Daging</th>
            <th>Jenis Daging</th>
            <?php foreach ($kriteria as $nama_kriteria): ?>
              <th><?= esc($nama_kriteria); ?></th>
            <?php endforeach; ?>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; ?>
          <?php if (!empty($terbobot)): ?>
            <?php foreach ($terbobot as $id_daging => $row): ?>
              <tr>
                <td><?= $no++; ?></td>
                <td><?= esc($row['kode_daging']); ?></td>
                <td class="text-start"><?= esc($row['jenis_daging']); ?></td>
                <?php foreach ($kriteria as $id_kriteria => $nama): ?>
                  <td><?= isset($row['nilai'][$id_kriteria]) ? number_format($row['nilai'][$id_kriteria], 4) : '0.0000'; ?></td>
                <?php endforeach; ?>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="<?= 3 + count($kriteria); ?>" class="text-center text-muted">Data belum dihitung.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <div class="mb-3 d-flex align-items-center">
      <form action="<?= base_url('terbobot/hitung'); ?>" method="post" style="display: inline-block;">
        <?= csrf_field(); ?>
        <button type="submit" class="btn btn-primary">Hitung Matriks Terbobot</button>
      </form>

      <form action="<?= base_url('terbobot/hapussemua'); ?>" method="post" style="display: inline-block;" onsubmit="return confirm('Yakin ingin menghapus semua data?');">
        <?= csrf_field(); ?>
        <button type="submit" class="btn btn-danger">Hapus Semua</button>
      </form>
    </div>
  </div>
</div>

<!-- Keterangan Rumus -->
<div class="container mt-4">
  <div class="table-wrapper">
    <h2>🧮 Keterangan</h2>
    <p><strong>Rumus Matriks Terbobot:</strong></p>
    <div class="math-box">
      y<sub>ij</sub> = r<sub>ij</sub> × w<sub>j</sub>
    </div>
    <p>Dengan:</p>
    <ul>
      <li><strong>r<sub>ij</sub></strong> : nilai normalisasi</li>
      <li><strong>w<sub>j</sub></strong> : bobot kriteria ke-j</li>
    </ul>
  </div>
</div>

<?= $this->endSection(); ?>
