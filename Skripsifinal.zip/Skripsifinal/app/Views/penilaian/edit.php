<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<style>
  body {
    background-color: #f1f5f9;
    font-family: 'Nunito', sans-serif;
  }

  .card {
    border: none;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  }

  .card-header {
  background-color: #120f30ff !important;
}

  .card-header h4 {
    margin-bottom: 0;
    font-weight: 700;
  }

  .card-body {
    padding: 2rem;
  }

  .form-label {
    font-weight: 600;
    color: #374151;
  }

  .form-control {
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    padding: 0.75rem 1rem;
    font-size: 1rem;
    min-height: 45px;
    transition: border-color 0.3s ease;
  }

  .form-control:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 0.15rem rgba(37, 99, 235, 0.25);
  }

  select.form-control {
    appearance: none;
    background-color: #fff;
    background-image: url("data:image/svg+xml,%3Csvg fill='none' stroke='gray' stroke-width='2' viewBox='0 0 24 24'%3E%3Cpath d='M19 9l-7 7-7-7'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 1rem center;
    background-size: 1rem;
    padding-right: 2.5rem;
  }

  .btn-success {
    background-color: #10b981;
    border: none;
    padding: 0.6rem 1.5rem;
    font-weight: 600;
    border-radius: 8px;
    transition: background-color 0.2s ease;
  }

  .btn-success:hover {
    background-color: #059669;
  }

  .btn-secondary {
    background-color: #6b7280;
    border: none;
    padding: 0.6rem 1.5rem;
    font-weight: 600;
    border-radius: 8px;
    transition: background-color 0.2s ease;
  }

  .btn-secondary:hover {
    background-color: #4b5563;
  }

  @media (max-width: 576px) {
    .card-body {
      padding: 1.5rem;
    }

    .btn-success, .btn-secondary {
      width: 100%;
      margin-top: 0.75rem;
    }

    .d-flex.justify-content-between {
      flex-direction: column-reverse;
      gap: 0.5rem;
    }
  }
</style>

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-10">
      <div class="card shadow-sm rounded-3">
        <div class="card-header bg-primary text-white">
          <h4 class="mb-0">Form Ubah Data Penilaian</h4>
        </div>
        <div class="card-body">
          <form action="<?= base_url('penilaian/ubah/' . $penilaian[0]['id_daging']); ?>" method="post">
            <?= csrf_field(); ?>
            <input type="hidden" name="_method" value="PUT">

            <div class="mb-3">
              <label class="form-label">Jenis Daging</label>
              <input type="text" class="form-control" value="<?= esc($daging[0]['jenis_daging']); ?>" readonly>
              <input type="hidden" name="id_daging" value="<?= esc($daging[0]['id_daging']); ?>">
            </div>

            <?php foreach ($kriteria as $k): ?>
              <div class="mb-3">
                <label class="form-label"><?= esc($k['nama_kriteria']); ?></label>
                <input type="hidden" name="id_kriteria[]" value="<?= $k['id_kriteria']; ?>">
                <select name="id_parameter[]" class="form-control" required>
                  <option value="">-- Pilih Nilai --</option>
                  <?php foreach ($parameter as $p): ?>
                    <?php if ($p['id_kriteria'] == $k['id_kriteria']): ?>
                      <option value="<?= $p['id_parameter']; ?>"
                        <?php foreach ($penilaian as $pn):
                          if ($pn['id_kriteria'] == $k['id_kriteria'] && $pn['id_parameter'] == $p['id_parameter']) echo 'selected'; 
                        endforeach; ?>>
                        <?= $p['nilai_parameter']; ?> - <?= $p['keterangan']; ?>
                      </option>
                    <?php endif; ?>
                  <?php endforeach; ?>
                </select>
              </div>
            <?php endforeach; ?>

            <div class="d-flex justify-content-between mt-4">
              <a href="<?= base_url('penilaian'); ?>" class="btn btn-secondary">Kembali</a>
              <button type="submit" class="btn btn-success">Simpan Perubahan</button>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<?= $this->endSection(); ?>
