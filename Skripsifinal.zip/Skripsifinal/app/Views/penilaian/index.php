<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<style>
  body {
    background-color: #f1f5f9;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  h2 {
    font-weight: 600;
    color: #1e3a8a;
    margin-bottom: 1.5rem;
  }

  .table-wrapper {
    background-color: #ffffff;
    padding: 2rem;
    border-radius: 14px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
    margin-bottom: 2rem;
  }

  .table {
    background-color: #ffffff;
    border-radius: 8px;
    overflow: hidden;
  }

  .table th {
    background-color: #1e3a8a;
    color: #ffffff;
    vertical-align: middle;
    text-align: center;
    font-weight: 600;
    font-size: 0.95rem;
  }

  .table td {
    background-color: #f8fafc;
    color: #1e293b;
    vertical-align: middle;
    text-align: center;
    font-size: 0.92rem;
  }

  .table tr:hover td {
    background-color: #e2e8f0;
  }

  .text-start {
    text-align: left !important;
  }

  .btn {
    font-weight: 500;
    padding: 0.4rem 0.8rem;
    border-radius: 6px;
    transition: all 0.2s ease-in-out;
  }

  .btn-sm {
    font-size: 0.8rem;
  }

  .btn-warning {
    background-color: #fde047;
    color: #1f2937;
    border: none;
  }

  .btn-warning:hover {
    background-color: #facc15;
    color: #111827;
  }

  .btn-danger {
    background-color: #f87171;
    border: none;
    color: white;
  }

  .btn-danger:hover {
    background-color: #ef4444;
  }

  .btn-primary {
    background-color: #3b82f6;
    border: none;
    color: white;
  }

  .btn-primary:hover {
    background-color: #2563eb;
  }

  .table-responsive {
    overflow-x: auto;
  }

  @media (max-width: 768px) {
    .btn-sm {
      display: block;
      width: 100%;
      margin-bottom: 0.5rem;
    }

    .table th, .table td {
      font-size: 0.85rem;
      white-space: nowrap;
    }
  }
</style>

<div class="container mt-5">
  <div class="table-wrapper">
    <h2>📋 Data Penilaian Daging Ayam</h2>

    <div class="table-responsive">
      <table class="table table-bordered table-hover">
        <thead>
          <tr>
            <th rowspan="2">No</th>
            <th rowspan="2">Kode Daging</th>
            <th rowspan="2">Jenis Daging</th>
            <th colspan="<?= count($kriteria); ?>">Nilai</th>
            <th rowspan="2">Aksi</th>
          </tr>
          <tr>
            <?php foreach ($kriteria as $nama): ?>
              <th><?= esc($nama); ?></th>
            <?php endforeach; ?>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; foreach ($penilaian as $id_daging => $p): ?>
            <tr>
              <td><?= $no++; ?></td>
              <td><?= esc($p['kode_daging']); ?></td>
              <td class="text-start"><?= esc($p['jenis_daging']); ?></td>
              <?php foreach ($kriteria as $id_kriteria => $nama): ?>
                <td><?= esc($p['nilai'][$id_kriteria] ?? '-'); ?></td>
              <?php endforeach; ?>
              <td>
                <a href="<?= base_url('penilaian/edit/' . $id_daging); ?>" class="btn btn-warning btn-sm">Edit</a>
                <form action="<?= base_url('penilaian/hapus/' . $id_daging); ?>" method="post" style="display:inline-block;" onsubmit="return confirm('Yakin ingin menghapus penilaian daging ayam ini?');">
                  <?= csrf_field(); ?>
                  <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <a href="<?= base_url('penilaian/tambah'); ?>" class="btn btn-primary mt-3">Tambah Penilaian</a>
  </div>
</div>

<?= $this->endSection(); ?>
