<!-- app/Views/layout/footer.php -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Toko Daging Ayam <?= date('Y') ?></span>
        </div>
    </div>
</footer>
