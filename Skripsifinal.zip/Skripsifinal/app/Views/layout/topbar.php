<style>
  .hover-yellow {
    color: #fbff00ff;
    transition: color 0.3s ease;
  }

  .hover-yellow:hover {
    color: #ff0000ff; /* merah saat hover */
  }

  .topbar-dark {
    background-color: #1f2937 !important; /* dark gray */
    color: #ffffff;
  }

  .topbar-dark .nav-link,
  .topbar-dark .navbar-nav .nav-item .nav-link span {
    color: #ffffff !important;
  }

  .topbar-dark .fa-bars {
    color: #ffffff;
  }
</style>

<nav class="navbar navbar-expand navbar-light topbar-dark topbar mb-4 static-top shadow position-relative">
    <!-- Sidebar Toggle -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>

    <!-- Center Title -->
    <div class="position-absolute w-100 text-center">
        <span class="font-weight-bold h5 mb-0 hover-yellow">
            Sistem Pemilihan Rekomendasi Daging Ayam Terbaik
        </span>
    </div>

    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">
        <?php 
            $role = session()->get('role'); 
            $nama = session()->get('nama_user');
        ?>
        <?php if ($role === 'admin' || $role === 'owner') : ?>
            <li class="nav-item">
                <span class="nav-link">
                    <span class="mr-2 d-none d-lg-inline fw-bold fs-3 hover-yellow">
                        Hi, <?= esc($nama) ?>
                    </span>
                </span>
            </li>
        <?php endif; ?>
    </ul>
</nav>
