<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<style>
  body {
    font-family: 'Nunito', sans-serif;
    background-color: #f1f5f9;
  }

  h1, h2 {
    font-weight: 700;
    color: #1e3a8a;
  }

  .table-wrapper {
    background: #ffffff;
    padding: 2rem;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  }

  .table thead th {
    background: #1e3a8a;
    color: #ffffff;
    font-weight: 600;
    font-size: 1rem;
    border: none;
    vertical-align: middle;
  }

  .table tbody td {
    background-color: #f9fafb;
    color: #1f2937;
    font-size: 0.95rem;
    vertical-align: middle;
  }

  .table tbody tr:hover td {
    background-color: #e5e7eb;
    transition: background 0.2s ease-in-out;
  }

  .btn-primary,
  .btn-success,
  .btn-danger {
    font-weight: 600;
    border-radius: 8px;
    transition: 0.2s ease-in-out;
  }

  .btn-primary {
    background-color: #2563eb;
    border: none;
  }

  .btn-primary:hover {
    background-color: #1d4ed8;
  }

  .btn-success {
    background-color: #10b981;
    border: none;
  }

  .btn-success:hover {
    background-color: #059669;
  }

  .btn-danger {
    background-color: #ef4444;
    border: none;
  }

  .btn-danger:hover {
    background-color: #dc2626;
  }

  .info-box {
    margin-top: 2rem;
    background: #ffffff;
    padding: 2rem;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.04);
    color: #374151;
    font-size: 0.95rem;
  }

  .info-box strong {
    color: #1e3a8a;
  }

  .info-box ul {
    padding-left: 1.5rem;
  }

  .info-box li {
    margin-bottom: 0.5rem;
  }

  @media (max-width: 768px) {
    h1, h2 {
      font-size: 1.5rem;
    }

    .table th, .table td {
      font-size: 0.85rem;
      white-space: nowrap;
    }

    .btn-sm {
      padding: 0.25rem 0.5rem;
    }
  }
</style>

<div class="container mt-4">
  <div class="row">
    <div class="col">
      <div class="table-wrapper">
        <h1 class="mb-4">📊 Daftar Bobot</h1>

        <div class="table-responsive">
          <table class="table table-hover align-middle text-center">
            <thead>
              <tr>
                <th>No</th>
                <th>Id Bobot</th>
                <th>Nilai Bobot</th>
                <th>Nilai Alternatif</th>
                <th>Keterangan</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php $no = 1; ?>
              <?php foreach($bobot as $b): ?>
              <tr>
                <td><?= $no++; ?></td>
                <td><?= esc($b['id_bobot']); ?></td>
                <td><?= esc($b['nilai_bobot']); ?></td>
                <td><?= number_format($b['nilai_bobot'] / 100, 2); ?></td>
                <td><?= esc($b['keterangan']); ?></td>
                <td>
                  <a href="<?= base_url('/bobot/edit/' . $b['id_bobot']); ?>" class="btn btn-success btn-sm">Ubah</a>
                  <form action="<?= base_url('/bobot/hapus/'.$b['id_bobot']); ?>" method="post" class="d-inline">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="_method" value="DELETE">
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                  </form>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <a href="<?= base_url('/bobot/tambah'); ?>" class="btn btn-primary mt-3">
          <i class="fas fa-plus"></i> Tambah Data
        </a>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col">
      <div class="info-box">
        <h2 class="mb-3">ℹ️ Keterangan</h2>
        <p>Berikut adalah rumus mencari nilai normalisasi pada tabel pembobotan:</p>
        <p><strong>Normalisasi = W<sub>j</sub> / (∑ W<sub>j</sub>)</strong></p>

        <p><strong>Keterangan:</strong></p>
        <ul>
          <li><strong>W<sub>j</sub></strong> : bobot untuk kriteria ke-j.</li>
          <li><strong>∑ W<sub>j</sub></strong> : total bobot dari semua kriteria.</li>
        </ul>

        <p><strong>Contoh perhitungan:</strong></p>
        <ul>
          <li>W₁ = 30 / (30 + 20 + 10 + 15 + 10 + 10 + 5) = 0.30</li>
          <li>W₂ = 20 / (30 + 20 + 10 + 15 + 10 + 10 + 5) = 0.20</li>
          <li>W₃ = 10 / (30 + 20 + 10 + 15 + 10 + 10 + 5) = 0.10</li>
          <li>W₄ = 15 / (30 + 20 + 10 + 15 + 10 + 10 + 5) = 0.15</li>
          <li>W₅ = 10 / (30 + 20 + 10 + 15 + 10 + 10 + 5) = 0.10</li>
          <li>W₆ = 10 / (30 + 20 + 10 + 15 + 10 + 10 + 5) = 0.10</li>
          <li>W₇ = 5 / (30 + 20 + 10 + 15 + 10 + 10 + 5) = 0.05</li>
        </ul>
      </div>
    </div>
  </div>
</div>

<?= $this->endSection(); ?>
