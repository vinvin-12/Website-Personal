<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<style>
  body {
    background-color: #f1f5f9;
    font-family: 'Nunito', sans-serif;
  }

  .form-container {
    background: #ffffff;
    padding: 2.5rem;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    transition: 0.3s ease;
    margin-top: 3rem;
  }

  h2 {
    font-weight: 800;
    color: #1f2937;
  }

  .form-label {
    font-weight: 600;
    color: #374151;
  }

  .form-control {
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    padding: 0.75rem;
    font-size: 1rem;
    transition: border-color 0.3s;
  }

  .form-control:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 0.15rem rgba(37, 99, 235, 0.25);
  }

  .btn-success {
    background-color: #10b981;
    border: none;
    padding: 0.6rem 1.5rem;
    font-weight: 600;
    border-radius: 8px;
    transition: background-color 0.2s ease;
  }

  .btn-success:hover {
    background-color: #059669;
  }

  .btn-secondary {
    margin-left: 0.5rem;
    background-color: #6b7280;
    border: none;
    padding: 0.6rem 1.5rem;
    font-weight: 600;
    border-radius: 8px;
    transition: background-color 0.2s ease;
  }

  .btn-secondary:hover {
    background-color: #4b5563;
  }

  @media (max-width: 576px) {
    .form-container {
      padding: 1.5rem;
    }
  }
</style>

<div class="container">
  <div class="row justify-content-center">
    <div class="col-lg-6 col-md-8 col-sm-12">
      <div class="form-container">
            <h2 class="mb-4">Form Ubah Data Bobot</h2>
            <form action="<?= base_url('bobot/ubah/' . $bobot['id_bobot']); ?>" method="post">
                <?= csrf_field(); ?>
                <input type="hidden" name="_method" value="PUT">

                <div class="mb-3">
                    <label for="id_bobot" class="form-label">Id Bobot</label>
                    <input type="text" class="form-control" id="id_bobot" name="id_bobot" value="<?= $bobot['id_bobot']; ?>" readonly>
                </div>

                <div class="mb-3">
                    <label for="nilai_bobot" class="form-label">Nilai Bobot</label>
                    <input type="text" class="form-control" id="nilai_bobot" name="nilai_bobot" value="<?= $bobot['nilai_bobot']; ?>" required>
                </div>

                <div class="mb-3">
                    <label for="keterangan" class="form-label">Keterangan</label>
                    <input type="text" class="form-control" id="keterangan" name="keterangan" value="<?= $bobot['keterangan']; ?>" required>
                </div>

                <button type="submit" class="btn btn-success">Ubah</button>
                <a href="<?= base_url('bobot/index'); ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>
