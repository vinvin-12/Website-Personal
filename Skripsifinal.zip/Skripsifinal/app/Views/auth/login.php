<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login</title>

    <!-- Custom fonts for this template -->
    <link href="<?= base_url('vendor/fontawesome-free/css/all.min.css') ?>" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?= base_url('css/sb-admin-2.min.css') ?>" rel="stylesheet">

    <!-- Modern Style Override -->
    <style>
        body.bg-gradient-primary {
            background: linear-gradient(to right, #ff0000, #ffff00); /* merah ke kuning */
            font-family: 'Nunito', sans-serif;
        }

        .card {
            border-radius: 1rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-4px);
        }

        .form-control-user {
            border-radius: 0.75rem;
            padding: 1rem;
            border: 1px solid #cbd5e1;
            font-size: 0.95rem;
        }

        .form-control-user:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25);
        }

        .btn-user {
            border-radius: 0.75rem;
            background-color: #3b82f6;
            border: none;
            transition: background-color 0.3s ease;
        }

        .btn-user:hover {
            background-color: #2563eb;
        }

        .custom-control-label {
            font-size: 0.85rem;
            color: #4b5563;
        }

        .text-center h1 {
            font-weight: 700;
            color: #1e293b;
        }

        .alert-danger {
            border-radius: 0.5rem;
            background-color: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        a.small {
            color: #64748b;
        }

        a.small:hover {
            color: #3b82f6;
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .custom-left-logo {
                display: none;
            }

            .card {
                margin-top: 2rem;
            }
        }
    </style>
</head>

<body class="bg-gradient-primary">

    <div class="container">
        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <!-- Logo Samping -->
                            <div class="col-lg-6 d-none d-lg-flex align-items-center justify-content-center custom-left-logo" style="background-color: white;">
                                <img src="<?= base_url('img/logo.png') ?>" alt="Logo" style="max-width: 80%; max-height: 80%;">
                            </div>
                            <!-- Form Login -->
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <!-- Flash Message Error -->
                                    <?php if (session()->getFlashdata('error')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <?= session()->getFlashdata('error') ?>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <!-- Heading -->
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Selamat Datang</h1>
                                    </div>
                                    
                                    <!-- Login Form -->
                                    <form class="user" method="post" action="<?= base_url('auth/ceklogin') ?>">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user"
                                                name="username" placeholder="Enter Username..." required>
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user"
                                                name="password" placeholder="Password" required>
                                        </div>
                                        <div class="form-group">
                                            <div class="custom-control custom-checkbox small">
                                                <input type="checkbox" class="custom-control-input" id="customCheck">
                                                <label class="custom-control-label" for="customCheck">Remember Me</label>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-user btn-block">
                                            Login
                                        </button>
                                    </form>
                                    
                                    <div class="text-center mt-3">
                                        <a class="small" href="<?= base_url('auth/lupapw'); ?>">Forgot Password?</a>
                                    </div>
                                </div> <!-- End Form -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- Bootstrap core JavaScript -->
    <script src="<?= base_url('vendor/jquery/jquery.min.js') ?>"></script>
    <script src="<?= base_url('vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>

    <!-- Core plugin JavaScript -->
    <script src="<?= base_url('vendor/jquery-easing/jquery.easing.min.js') ?>"></script>

    <!-- Custom scripts for all pages -->
    <script src="<?= base_url('js/sb-admin-2.min.js') ?>"></script>

</body>

</html>
