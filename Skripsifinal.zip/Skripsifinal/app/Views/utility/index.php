<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<style>
  body {
    font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f9fafb;
    color: #1f2937;
  }

  h2 {
    font-weight: 700;
    font-size: 1.75rem;
    color: #111827;
    margin-bottom: 1.5rem;
  }

  .table-wrapper {
    background: #ffffff;
    padding: 2rem;
    border-radius: 16px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.06);
    transition: all 0.3s ease;
  }

  .table-wrapper:hover {
    box-shadow: 0 10px 28px rgba(0, 0, 0, 0.08);
  }

  .table {
    border-collapse: collapse;
    width: 100%;
  }

  .table thead {
    background-color: #f3f4f6;
  }

  .table th, .table td {
    padding: 0.75rem;
    vertical-align: middle;
    text-align: center;
    border: 1px solid #e5e7eb;
    font-size: 0.95rem;
  }

  .table th {
    color: #374151;
    font-weight: 600;
  }

  .table td {
    color: #4b5563;
  }

  .btn {
    border-radius: 8px;
    font-weight: 600;
    padding: 0.5rem 1.2rem;
    font-size: 0.95rem;
    transition: background-color 0.25s ease;
  }

  .btn-primary {
    background-color: #3b82f6;
    color: white;
    border: none;
  }

  .btn-primary:hover {
    background-color: #2563eb;
  }

  .btn-danger {
    background-color: #ef4444;
    color: white;
    border: none;
  }

  .btn-danger:hover {
    background-color: #dc2626;
  }

  .math-block {
    background: #f9fafb;
    padding: 1rem 1.5rem;
    border-left: 4px solid #3b82f6;
    border-radius: 8px;
    font-family: 'Fira Code', monospace;
    font-size: 0.95rem;
    color: #374151;
    margin-bottom: 1.5rem;
  }

  ul li {
    margin-bottom: 0.5rem;
    font-size: 0.95rem;
    color: #374151;
  }

  .btn + .btn {
    margin-left: 0.75rem;
  }

  .text-muted {
    color: #9ca3af !important;
  }

  .text-start {
    text-align: left !important;
  }
</style>

<div class="container mt-5">
  <div class="table-wrapper">
    <h2>📊 Data Nilai Utility</h2>

    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>No</th>
          <th>Kode Daging</th>
          <th>Jenis Daging</th>
          <?php foreach ($kriteria as $nama_kriteria): ?>
            <th><?= esc($nama_kriteria); ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
        <?php $no = 1; ?>
        <?php if (!empty($utility)): ?>
          <?php foreach ($utility as $daging_id => $u): ?>
            <tr>
              <td><?= $no++; ?></td>
              <td><?= esc($u['kode_daging']); ?></td>
              <td class="text-start"><?= esc($u['jenis_daging']); ?></td>
              <?php foreach ($kriteria as $id_kriteria => $nama_kriteria): ?>
                <td><?= isset($u['nilai'][$id_kriteria]) ? number_format($u['nilai'][$id_kriteria], 2) : '0.00'; ?></td>
              <?php endforeach; ?>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="<?= 3 + count($kriteria); ?>" class="text-center text-muted">
              Data utility belum dihitung. Silakan klik tombol <strong>"Hitung Utility"</strong>.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>

    <div class="mb-3 mt-3">
      <form action="<?= base_url('utility/hitung'); ?>" method="post" style="display: inline-block;">
        <?= csrf_field(); ?>
        <button type="submit" class="btn btn-primary">Hitung Utility</button>
      </form>

      <form action="<?= base_url('utility/hapussemua'); ?>" method="post" style="display: inline-block;" onsubmit="return confirm('Yakin ingin menghapus semua data utility?');">
        <?= csrf_field(); ?>
        <button type="submit" class="btn btn-danger">Hapus Semua Data Utility</button>
      </form>
    </div>
  </div>
</div>

<div class="container mt-4">
  <div class="table-wrapper">
    <h2>📘 Keterangan</h2>

    <p><strong>Rumus perhitungan nilai utility:</strong></p>

    <div class="math-block">
      <strong>Untuk Kriteria Benefit:</strong><br>
      ui(ai) = (Cout − Cmin) / (Cmax − Cmin)
    </div>

    <div class="math-block">
      <strong>Untuk Kriteria Cost:</strong><br>
      ui(ai) = (Cmax − Cout) / (Cmax − Cmin)
    </div>

    <p><strong>Keterangan:</strong></p>
    <ul>
      <li><strong>u<sub>i</sub>(a<sub>i</sub>)</strong>: Nilai utility untuk kriteria ke-i</li>
      <li><strong>C<sub>max</sub></strong>: Nilai maksimal dari kriteria</li>
      <li><strong>C<sub>min</sub></strong>: Nilai minimal dari kriteria</li>
      <li><strong>C<sub>out</sub></strong>: Nilai alternatif (data daging) untuk kriteria ke-i</li>
    </ul>
  </div>
</div>

<?= $this->endSection(); ?>
