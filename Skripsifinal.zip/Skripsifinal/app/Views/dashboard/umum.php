<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<!-- Modern UI CSS Styling -->
<style>
  body {
    font-family: 'Nunito', sans-serif;
    background-color: #f4f6f8;
  }

  /* Sidebar Styling */
  .sidebar {
    background-color: #dc2626 !important;
  }

  .sidebar,
  .sidebar a,
  .sidebar i,
  .sidebar span,
  .sidebar .nav-link {
    color: #ffffff !important;
    font-weight: 600;
  }

  .sidebar .nav-link:hover {
    background-color: rgba(255, 255, 255, 0.2);
    color: #ffffff !important;
  }

  .sidebar .active {
    background-color: rgba(255, 255, 255, 0.3);
    color: #ffffff !important;
    font-weight: 700;
  }

  .company-description {
    max-width: 900px;
    margin: 3rem auto;
    text-align: center;
    color: #2c3e50;
    padding: 0 1rem;
  }

  .company-description h2 {
    font-size: 2.5rem;
    font-weight: 700;
    color: #fa0f0fff;
    margin-bottom: 1.5rem;
  }

  .highlight-box {
    background: linear-gradient(to right, #f71d15ff);
    padding: 2rem;
    border-radius: 1rem;
    margin-bottom: 3rem;
    box-shadow: 0 8px 20px rgba(255, 255, 255, 0.05);
    transition: transform 0.3s ease;
  }

  .highlight-box:hover {
    transform: translateY(-4px);
  }

  .highlight-box p {
    font-size: 1.250rem;
    font-weight: 500;
    color: #fffb00ff;
  }

  .text-left-section {
    text-align: left;
    margin-top: 2rem;
  }

  .text-left-section h2 {
    color: #14b8a6;
    font-size: 1.75rem;
    margin-top: 1.5rem;
    font-weight: 600;
  }

  .text-left-section ul {
    margin-top: 1rem;
    padding-left: 1.5rem;
  }

  .text-left-section li {
    margin-bottom: 0.75rem;
    line-height: 1.7;
    font-size: 1rem;
    color: #fffb00ff;
  }

  .text-left-section p {
    font-size: 1rem;
    color: #93a2bbff;
    line-height: 1.6;
  }

  /* Gallery */
  .image-gallery {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-top: 2.5rem;
  }

  .image-item {
    text-align: center;
  }

  .image-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    border-radius: 1rem;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease;
  }

  .image-item img:hover {
    transform: scale(1.03);
  }

  .image-item p {
    margin-top: 8px;
    font-size: 14px;
    font-weight: 500;
    color: #374151; /* abu-abu gelap */
  }

  /* Contact */
  .contact-section {
    background-color: #ffffff;
    border-radius: 1rem;
    padding: 2rem;
    max-width: 900px;
    margin: 4rem auto;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.06);
  }

  .contact-section h3 {
    font-size: 2rem;
    font-weight: 700;
    color: #2563eb;
    margin-bottom: 1rem;
  }

  .contact-section p {
    font-size: 1rem;
    color: #4b5563;
  }

  .contact-section ul {
    list-style: none;
    padding-left: 0;
    margin-top: 1.5rem;
  }

  .contact-section li {
    margin-bottom: 0.75rem;
    font-size: 1rem;
    color: #515137ff;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    flex-wrap: wrap;
  }

  .contact-section i {
    color: #10b981;
    font-size: 1.1rem;
  }

  @media (max-width: 768px) {
    .company-description,
    .contact-section {
      padding: 1rem;
    }

    .contact-section li {
      font-size: 0.95rem;
      flex-direction: column;
      align-items: flex-start;
    }
  }
</style>

<!-- Content Start -->
<div class="company-description">
  <h2>Tentang Kami</h2>
  <div class="highlight-box">
    <p><strong>Sistem Pemilihan Rekomendasi Daging Ayam</strong> adalah solusi digital cerdas untuk membantu memilih jenis daging ayam berdasarkan kriteria yang sesuai. Dirancang untuk membantu kebutuhan bisnis UMKM.</p>
  </div>

  <div class="text-left-section">
    <div class="highlight-box text-left">
      <ul>
        <li>Menyediakan informasi edukatif tentang jenis daging ayam.</li>
        <li>Memberikan rekomendasi sesuai kriteria pengguna.</li>
        <li>Mendukung pelaku kuliner melalui solusi digital.</li>
        <li>Meningkatkan kesadaran akan gizi dan kualitas pangan.</li>
      </ul>
    </div>
  </div>

  <!-- GALLERY FOTO -->
  <div class="image-gallery">
    <div class="image-item">
      <img src="<?= base_url('img/broiler frozen.jpg') ?>" alt="Ayam Broiler Frozen Pre- marinasi">
      <p>Ayam Broiler Frozen Pre-marinated</p>
    </div>

    <div class="image-item">
      <img src="<?= base_url('img/ayam kampung.jpg') ?>" alt="Ayam Kampung">
      <p>Ayam Kampung segar</p>
    </div>

    <div class="image-item">
      <img src="<?= base_url('img/ayam broiler.jpg') ?>" alt="Ayam Broiler">
      <p>Ayam Broiler segar</p>
    </div>

    <div class="image-item">
      <img src="<?= base_url('img/ayam cemani.jpg') ?>" alt="Ayam Cemani">
      <p>Ayam Cemani</p>
    </div>

    <div class="image-item">
      <img src="<?= base_url('img/ayam broiler frozen.jpg') ?>" alt="Ayam Broiler Frozen">
      <p>Ayam Broiler Frozen</p>
    </div>
  </div>

  <!-- Kontak -->
  <div class="contact-section text-center">
    <h3>Hubungi Kami</h3>
    <p>Punya pertanyaan atau ingin bekerja sama? Hubungi kami melalui:</p>
    <ul>
      <li><i class="fas fa-phone-alt"></i><strong>Telepon:</strong> 0812-3456-7890</li>
      <li><i class="fas fa-envelope"></i><strong>Email:</strong> info@tokodagingayam.co.id</li>
      <li><i class="fas fa-map-marker-alt"></i><strong>Alamat:</strong> Jl. Palem Indah No. 88, Tangerang Selatan, Indonesia</li>
    </ul>
  </div>
</div>
<!-- Content End -->

<?= $this->endSection(); ?>
