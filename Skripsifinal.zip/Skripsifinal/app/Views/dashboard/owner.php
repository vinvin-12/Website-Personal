<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<style>
  body, .custom-card, .custom-card-header, .table, h2, h3, p, span {
    font-family: 'Nunito', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,
      Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
  }
  .custom-card {
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(255, 0, 0, 0.15);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    background: #ffffff;
    color: #333;
    text-align: center;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
  }
  .custom-card-header {
    background: linear-gradient(45deg, #ff0000ff);
    color: yellow;
    border-radius: 12px 12px 0 0;
    padding: 1rem 1.5rem;
    font-weight: 600;
    font-size: 1.25rem;
  }
  .custom-badge-terpilih {
    background-color: #28a745;
    color: white;
    padding: 0.25em 0.6em;
    border-radius: 0.35rem;
    font-size: 0.85rem;
  }
  .custom-badge-default {
    background-color: #6c757d;
    color: white;
    padding: 0.25em 0.6em;
    border-radius: 0.35rem;
    font-size: 0.85rem;
  }
  .table thead th {
    background-color: #ff0000ff;
    color: yellow;
  }
</style>

<div class="container-fluid mt-4">
  <!-- Intro Section -->
  <div class="row mb-4">
    <div class="col-lg-12">
      <div class="alert alert-info shadow-sm rounded">
        <h4 class="mb-2"><i class="fas fa-info-circle"></i> Selamat Datang di Sistem Pemilihan Rekomendasi Daging Ayam Terbaik</h4>
        <p class="mb-0">
          Dashboard ini menyajikan ringkasan informasi terbaru dari sistem, termasuk grafik nilai daging ayam terbaru, daftar daging ayam yang terpilih, serta daging ayam dengan peringkat terbaik berdasarkan nilai akhir dan preferensi.
        </p>
      </div>
    </div>
  </div>

  <!-- Grafik Nilai Akhir -->
  <div class="row mb-4">
    <div class="col-lg-8">
      <div class="custom-card">
        <div class="custom-card-header">Grafik Nilai Akhir Daging</div>
        <canvas id="nilaiDagingChart" height="300"></canvas>
      </div>
    </div>

    <!-- Daftar Daging Terpilih -->
    <div class="col-lg-4">
      <div class="custom-card">
        <div class="custom-card-header">Daging Terpilih Terbaru</div>
        <ul class="list-group list-group-flush text-left">
          <?php if (!empty($topDaging)): ?>
            <?php foreach($topDaging as $dag): ?>
              <li class="list-group-item">
                <strong><?= esc($dag['jenis_daging']) ?></strong><br>
                Nilai: <?= number_format($dag['total_nilai'], 4) ?>
              </li>
            <?php endforeach; ?>
          <?php else: ?>
            <li class="list-group-item">Tidak ada data daging terpilih</li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </div>

  <!-- Tabel Nilai Akhir -->
  <div class="row">
    <div class="col-12">
      <div class="custom-card">
        <div class="custom-card-header">Nilai Akhir Terbaru</div>
        <div class="table-responsive">
          <table class="table table-striped mb-0">
            <thead>
              <tr>
                <th>Jenis Daging Ayam</th>
                <th>Nilai Akhir</th>
                <th>Ranking</th>
                <th>Keterangan</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($ranking)): ?>
                <?php foreach (array_slice($ranking, 0, 3) as $i => $row): ?>
                  <tr>
                    <td><?= esc($row['jenis_daging']) ?></td>
                    <td><?= number_format($row['total_nilai'], 4) ?></td>
                    <td><?= $i + 1 ?></td>
                    <td>
                      <?php if ($i == 0): ?>
                        <span class="custom-badge-terpilih">Terpilih</span>
                      <?php else: ?>
                        <span class="custom-badge-default">-</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="4" class="text-center">Tidak ada data nilai akhir</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- Tabel Nilai Preferensi -->
  <div class="row mt-4">
    <div class="col-12">
      <div class="custom-card">
        <div class="custom-card-header">Nilai Preferensi (TOPSIS)</div>
        <div class="table-responsive">
          <table class="table table-striped mb-0">
            <thead>
              <tr>
                <th>No</th>
                <th>Kode Daging</th>
                <th>Jenis Daging</th>
                <th>Nilai Preferensi</th>
                <th>Keterangan</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($preferensi)) : ?>
                <?php $no = 1; foreach ($preferensi as $item): ?>
                  <tr>
                    <td><?= $no ?></td>
                    <td><?= esc($item['kode_daging']) ?></td>
                    <td><?= esc($item['jenis_daging']) ?></td>
                    <td><?= number_format($item['nilai_preferensi'], 4) ?></td>
                    <td>
                      <?php if ($no == 1): ?>
                        <span class="custom-badge-terpilih">Terbaik</span>
                      <?php else: ?>
                        <span class="custom-badge-default">-</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                  <?php $no++; ?>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="5" class="text-center">Belum ada data preferensi</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  const ctx = document.getElementById('nilaiDagingChart').getContext('2d');
  const nilaiDagingChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: <?= json_encode($dagingNames ?? []) ?>,
      datasets: [{
        label: 'Nilai Akhir',
        data: <?= json_encode($dagingScores ?? []) ?>,
        backgroundColor: 'rgba(23, 162, 184, 0.7)',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: 'rgba(23, 162, 184, 1)'
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true,
          ticks: { precision: 4 }
        }
      },
      plugins: {
        legend: { display: false }
      }
    }
  });
</script>

<?= $this->endSection(); ?>
