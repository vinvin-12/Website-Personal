<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<!-- Modern UI Styling -->
<style>
  body,
  .custom-card,
  .custom-card-header,
  .table,
  h2, h3, p, span {
    font-family: 'Nunito', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,
      Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
  }

  .custom-card {
    border-radius: 16px;
    box-shadow: 0 10px 25px rgba(255, 0, 0, 0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    background: linear-gradient(135deg, #1f2937, #374151);
    color: white !important;
    text-align: center;
    position: relative;
    overflow: hidden;
  }

  .custom-card:hover {
    transform: translateY(-6px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
  }

  .custom-card-header {
    background: linear-gradient(45deg, #0ea5e9, #0369a1);
    color: white;
    border-top-left-radius: 16px;
    border-top-right-radius: 16px;
    padding: 1rem 1.5rem;
    font-weight: 600;
    font-size: 1.25rem;
    text-align: center;
  }

  .small-box {
    border-radius: 1rem;
    padding: 2rem 1.5rem;
    position: relative;
    overflow: hidden;
    color: white !important;
  }

  .small-box .inner h3 {
    font-size: 2.25rem;
    margin: 0;
    font-weight: 700;
  }

  .small-box .inner p {
    font-size: 1.1rem;
    margin: 0.5rem 0 0;
    font-weight: 500;
  }

  .small-box-footer {
    display: inline-block;
    margin-top: 1rem;
    font-size: 0.95rem;
    color: white !important;
    transition: opacity 0.2s ease;
  }

  .small-box-footer:hover {
    text-decoration: underline;
    opacity: 0.9;
  }

  .icon {
    position: absolute;
    top: 1.2rem;
    right: 1.5rem;
    font-size: 2.5rem;
    opacity: 0.3;
  }

  .alert-info {
    background: linear-gradient(to right, #e0f2fe, #bae6fd);
    border: none;
    color: #0044ffff;
  }

  .alert-info h4 {
    font-weight: 700;
  }

  .info-system-text {
    color: white !important; /* ✅ Diubah jadi putih agar terlihat */
    text-align: left;
    font-size: 1rem;
  }

  @media (max-width: 768px) {
    .custom-card,
    .custom-card-header,
    .small-box {
      padding: 1.25rem;
    } 

    .icon {
      font-size: 2rem;
      top: 0.8rem;
      right: 1rem;
    }
  }
</style>

<div class="container-fluid mt-4">
  <div class="row mb-4">
    <div class="col-lg-12">
      <div class="alert alert-info shadow-sm rounded">
        <h4 class="mb-2"><i class="fas fa-info-circle"></i> Selamat Datang di Sistem Pemilihan Rekomendasi Daging Ayam Terbaik</h4>
        <p class="mb-0">
          Dashboard ini menyajikan ringkasan informasi terbaru dari sistem, termasuk jumlah total kriteria penilaian dan daftar daging yang terdaftar.
          Gunakan informasi ini untuk memantau performa dan membuat keputusan pemilihan daging ayam secara objektif dan terukur.
        </p>
      </div>
    </div>
  </div>

  <div class="row justify-content-center">
    <!-- Box for Total Kriteria -->
    <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
      <div class="small-box bg-danger custom-card text-white">
        <div class="inner text-center">
          <h3><?= esc($totalKriteria) ?></h3>
          <p>Total Kriteria</p>
        </div>
        <div class="icon">
          <i class="ion ion-clipboard"></i>
        </div>
        <a href="<?= base_url('kriteria/index'); ?>" class="small-box-footer text-white">More Detail <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div>

    <!-- Box for Total Daging -->
    <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
      <div class="small-box bg-warning custom-card text-white">
        <div class="inner text-center">
          <h3><?= esc($totaldaging) ?></h3>
          <p>Total Daging Ayam</p>
        </div>
        <div class="icon">
          <i class="ion ion-person-stalker"></i>
        </div>
        <a href="<?= base_url('daging/index'); ?>" class="small-box-footer text-white">More Detail <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div>

    <!-- Box for Total Parameter -->
    <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
      <div class="small-box bg-info custom-card text-white">
        <div class="inner text-center">
          <h3><?= esc($totalParameter ?? 0) ?></h3>
          <p>Total Parameter</p>
        </div>
        <div class="icon">
          <i class="ion ion-settings"></i>
        </div>
        <a href="<?= base_url('nilaiparameter/index'); ?>" class="small-box-footer text-white">More Detail <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div>
  </div>

  <!-- Info Sistem -->
  <div class="custom-card mb-5 p-3">
    <div class="custom-card-header">
      Informasi Sistem
    </div>
    <div class="mt-3 info-system-text">
      <p><strong>Versi Aplikasi:</strong> 1.0.0</p>
      <p><strong>Tanggal Update Data Terakhir:</strong> <?= date_default_timezone_set('Asia/Jakarta') ? date('d-m-Y H:i') : '' ?></p>
      <p><strong>Catatan:</strong> Pastikan semua data daging ayam dan kriteria telah diperbarui sebelum melakukan evaluasi.</p>
    </div>
  </div>
</div>

<?= $this->endSection(); ?>
