<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<!-- Modern Styling -->
<style>
  body {
    font-family: 'Segoe UI', sans-serif;
    background-color: #f9fafb;
  }

  h2 {
    font-weight: 600;
    color: #1f2937;
    margin-bottom: 1.5rem;
  }

  .table-container {
    background-color: #ffffff;
    padding: 2rem;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  }

  .table th {
    background-color: #f3f4f6 !important;
    color: #111827;
    text-align: center;
    vertical-align: middle;
  }

  .table td {
    text-align: center;
    vertical-align: middle;
    font-size: 0.95rem;
    color: #374151;
  }

  .btn {
    border-radius: 6px;
    font-weight: 500;
    padding: 0.45rem 1.1rem;
    margin-top: 1rem;
  }

  .btn-primary {
    background-color: #3b82f6;
    border: none;
  }

  .btn-primary:hover {
    background-color: #2563eb;
  }

  .btn-danger {
    background-color: #ef4444;
    border: none;
  }

  .btn-danger:hover {
    background-color: #dc2626;
  }

  .alert-success {
    background-color: #d1fae5;
    color: #065f46;
    border-left: 5px solid #10b981;
    border-radius: 6px;
    padding: 1rem;
    margin-bottom: 1.5rem;
  }

  .form-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 0.75rem;
    margin-top: 1rem;
  }
</style>

<!-- Konten Halaman -->
<div class="container mt-5">
  <div class="table-container">
    <h2>📈 Solusi Ideal Positif & Negatif</h2>

    <?php if (session()->getFlashdata('success')): ?>
      <div class="alert alert-success">
        <?= session()->getFlashdata('success'); ?>
      </div>
    <?php endif; ?>

    <div class="table-responsive">
      <table class="table table-bordered table-striped mt-3">
        <thead>
          <tr>
            <th>No</th>
            <th>Kriteria</th>
            <th>Ideal Positif (+)</th>
            <th>Ideal Negatif (−)</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($ideal)): ?>
            <?php $no = 1; ?>
            <?php foreach ($ideal as $row): ?>
              <tr>
                <td><?= $no++; ?></td>
                <td><?= esc($row['nama_kriteria']); ?></td>
                <td><?= number_format($row['ideal_positif'], 4); ?></td>
                <td><?= number_format($row['ideal_negatif'], 4); ?></td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="4" class="text-center text-muted">Belum ada data solusi ideal.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <div class="form-buttons">
      <form action="<?= base_url('ideal/hitung'); ?>" method="post">
        <?= csrf_field(); ?>
        <button type="submit" class="btn btn-primary">Hitung Ideal</button>
      </form>

      <form action="<?= base_url('ideal/hapussemua'); ?>" method="post" onsubmit="return confirm('Yakin ingin menghapus semua data?');">
        <?= csrf_field(); ?>
        <button type="submit" class="btn btn-danger">Hapus Semua</button>
      </form>
    </div>
  </div>
</div>

<?= $this->endSection(); ?>
