<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<style>
  body {
    font-family: 'Nunito', sans-serif;
    background-color: #f3f4f6;
  }

  .container h1 {
    color: #1e3a8a;
    font-weight: 700;
    margin-bottom: 1.5rem;
  }

  .table-wrapper {
    background-color: #ffffff;
    padding: 2rem;
    border-radius: 16px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
  }

  .table thead th {
    background-color: #1e3a8a;
    color: white;
    font-weight: 600;
    text-align: center;
    border: none;
    font-size: 0.95rem;
  }

  .table tbody td {
    background-color: #f9fafb;
    color: #1f2937;
    vertical-align: middle;
    font-size: 0.95rem;
    text-align: center;
  }

  .table tbody tr:hover td {
    background-color: #e5e7eb;
    transition: background 0.2s ease-in-out;
  }

  .btn {
    font-weight: 600;
    padding: 0.35rem 0.75rem;
    border-radius: 8px;
    transition: 0.2s ease-in-out;
  }

  .btn-success {
    background-color: #10b981;
    border: none;
  }

  .btn-success:hover {
    background-color: #059669;
  }

  .btn-danger {
    background-color: #ef4444;
    border: none;
  }

  .btn-danger:hover {
    background-color: #dc2626;
  }

  .btn-primary {
    background-color: #2563eb;
    border: none;
  }

  .btn-primary:hover {
    background-color: #1d4ed8;
  }

  @media (max-width: 768px) {
    .table th, .table td {
      font-size: 0.85rem;
    }

    .btn-sm {
      padding: 0.25rem 0.5rem;
    }

    h1 {
      font-size: 1.5rem;
    }
  }
</style>

<div class="container mt-5">
  <div class="row">
    <div class="col">
      <div class="table-wrapper">
        <h1>📋 Daftar Kriteria</h1>
        <div class="table-responsive">
          <table class="table table-hover table-bordered align-middle">
            <thead>
              <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Kriteria</th>
                <th scope="col">Kode Kriteria</th>
                <th scope="col">Jenis Kriteria</th>
                <th scope="col">Nilai Bobot Alternatif</th>
                <th scope="col">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php $no = 1; ?>
              <?php foreach($kriteria as $k): ?>
              <tr>
                <td><?= $no++; ?></td>
                <td><?= esc($k['nama_kriteria']); ?></td>
                <td><?= esc($k['kd_kriteria']); ?></td>
                <td><?= esc($k['jenis_kriteria']); ?></td>
                <td><?= number_format($k['nilai_bobot'] / 100, 2); ?></td>
                <td>
                  <a href="<?= base_url('/kriteria/edit/' . $k['id_kriteria']); ?>" class="btn btn-success btn-sm">Ubah</a>
                  <form action="<?= base_url('/kriteria/hapus/'.$k['id_kriteria']); ?>" method="post" class="d-inline">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="_method" value="DELETE">
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                  </form>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <a href="<?= base_url('/kriteria/tambah'); ?>" class="btn btn-primary mt-3">
          <i class="fas fa-plus"></i> Tambah Data
        </a>
      </div>
    </div>
  </div>
</div>

<?= $this->endSection(); ?>
