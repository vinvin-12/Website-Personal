<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<style>
  body {
    background-color: #f1f5f9;
    font-family: 'Nunito', sans-serif;
  }

  .form-container {
    background: #ffffff;
    padding: 2.5rem;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    transition: 0.3s ease;
    margin-top: 3rem;
  }

  h2 {
    font-weight: 800;
    color: #1f2937;
  }

  .form-label {
    font-weight: 600;
    color: #374151;
  }

  .form-control {
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    padding: 0.75rem 1rem;
    font-size: 1rem;
    line-height: 1.5;
    height: auto; /* pastikan tinggi otomatis */
    min-height: 45px; /* agar tidak terlalu kecil */
    box-sizing: border-box;
    transition: border-color 0.3s;
  }

  select.form-control {
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    background-color: #fff;
    background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'%3E%3Cpath fill='%23444' d='M2 0L0 2h4zm0 5L0 3h4z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 1rem center;
    background-size: 0.65rem auto;
    padding-right: 2.5rem;
  }

  .form-control:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 0.15rem rgba(37, 99, 235, 0.25);
  }

  .btn-success {
    background-color: #10b981;
    border: none;
    padding: 0.6rem 1.5rem;
    font-weight: 600;
    border-radius: 8px;
    transition: background-color 0.2s ease;
  }

  .btn-success:hover {
    background-color: #059669;
  }

  .btn-secondary {
    margin-left: 0.5rem;
    background-color: #6b7280;
    border: none;
    padding: 0.6rem 1.5rem;
    font-weight: 600;
    border-radius: 8px;
    transition: background-color 0.2s ease;
  }

  .btn-secondary:hover {
    background-color: #4b5563;
  }

  @media (max-width: 576px) {
    .form-container {
      padding: 1.5rem;
    }
  }
</style>

<div class="container">
  <div class="row justify-content-center">
    <div class="col-lg-6 col-md-8 col-sm-12">
      <div class="form-container">
        <h2>Tambah Data Kriteria</h2>
        <form action="<?= base_url('kriteria/simpan'); ?>" method="post">
          <?= csrf_field(); ?>

          <div class="mb-2">
            <label for="id_kriteria" class="form-label">ID Kriteria</label>
            <input type="text" class="form-control" id="id_kriteria" name="id_kriteria" required>
          </div>

          <div class="mb-2">
            <label for="nama_kriteria" class="form-label">Nama Kriteria</label>
            <input type="text" class="form-control" id="nama_kriteria" name="nama_kriteria" required>
          </div>

          <div class="mb-2">
            <label for="kd_kriteria" class="form-label">Kode Kriteria</label>
            <input type="text" class="form-control" id="kd_kriteria" name="kd_kriteria" required>
          </div>

          <div class="mb-2">
            <label for="jenis_kriteria" class="form-label">Jenis</label>
            <select class="form-control" id="jenis_kriteria" name="jenis_kriteria" required>
              <option value="">-- Pilih --</option>
              <option value="Benefit">Benefit</option>
              <option value="Cost">Cost</option>
            </select>
          </div>

          <div class="mb-2">
            <label for="id_bobot" class="form-label">Bobot</label>
            <select class="form-control" id="id_bobot" name="id_bobot" required>
              <option value="">-- Pilih Bobot --</option>
              <?php foreach ($bobot as $b): ?>
                <option value="<?= $b['id_bobot']; ?>"><?= $b['nilai_bobot']; ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <button type="submit" class="btn btn-success">Tambah</button>
          <a href="<?= base_url('kriteria/index'); ?>" class="btn btn-secondary">Kembali</a>
        </form>
      </div>
    </div>
  </div>
</div>

<?= $this->endSection(); ?>
