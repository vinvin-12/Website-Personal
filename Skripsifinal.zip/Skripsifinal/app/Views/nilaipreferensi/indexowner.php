<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<style>
    .custom-badge-terpilih {
        display: inline-block;
        padding: 0.35rem 0.75rem;
        font-size: 0.875rem;
        font-weight: 600;
        color: #fff;
        background-color: #198754;
        border-radius: 0.5rem;
    }

    .custom-badge-default {
        display: inline-block;
        padding: 0.35rem 0.75rem;
        font-size: 0.875rem;
        font-weight: 500;
        color: #6c757d;
        background-color: #f1f3f5;
        border-radius: 0.5rem;
    }

    h2 {
        font-weight: 700;
        color: #000; /* Judul hitam */
    }

    .table thead th {
        background-color: #f1f3f5;
        color: #343a40;
        text-transform: uppercase;
        font-size: 0.85rem;
        border-bottom: 2px solid #dee2e6;
        text-align: center; /* Judul kolom center */
    }

    .table td, .table th {
        vertical-align: middle;
        font-size: 0.95rem;
    }

    .btn-success {
        font-weight: 500;
        padding: 0.5rem 1.25rem;
    }

    .table-hover tbody tr:hover {
        background-color: #f8f9fa;
    }

    .table td:first-child,
    .table td:last-child {
        text-align: center;
    }

    .table td:nth-child(2) {
        text-align: left;
    }

    .badge {
        font-size: 0.95rem;
        border-radius: 0.5rem;
    }

    .card {
        border-radius: 1rem;
    }

    .btn-print {
        transition: all 0.3s ease-in-out;
    }

    .btn-print:hover {
        background-color: #157347;
        color: #fff;
        border-color: #157347;
    }
</style>

<div class="container my-5">
    <div class="text-center mb-4">
        <h2 class="fw-semibold">Ranking Alternatif Daging Ayam</h2>
        <p class="text-muted fs-6">Data peringkat terbaik berdasarkan hasil perhitungan preferensi.</p>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body p-4">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 10%;">No</th>
                            <th>Jenis Daging</th>
                            <th style="width: 20%;">Terpilih</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($preferensi as $i => $row): ?>
                        <tr class="<?= $i == 0 ? 'table-success' : '' ?>">
                            <td class="fw-bold"><?= $i + 1 ?></td>
                            <td><?= esc($row['jenis_daging']) ?></td>
                            <td>
                                <?php if ($i == 0): ?>
                                    <span class="badge bg-success text-white">Terpilih</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="text-end mt-4">
                <a href="<?= base_url('preferensi/cetakpdfowner'); ?>" class="btn btn-outline-success btn-lg rounded-pill btn-print" target="_blank">
                    <i class="bi bi-printer me-1"></i> Cetak Ranking
                </a>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>
