<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<!-- Gaya modern -->
<style>
  body {
    font-family: 'Segoe UI', sans-serif;
    background-color: #f9fafb;
  }

  h2, h3 {
    font-weight: 600;
    color: #1f2937;
    margin-bottom: 1.5rem;
  }

  .table-container {
    background-color: #ffffff;
    padding: 2rem;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    margin-bottom: 2rem;
  }

  .table th {
    background-color: #f3f4f6 !important;
    color: #111827;
    text-align: center;
    vertical-align: middle;
  }

  .table td {
    text-align: center;
    vertical-align: middle;
    font-size: 0.95rem;
    color: #374151;
  }

  .btn {
    border-radius: 6px;
    font-weight: 500;
    padding: 0.45rem 1.1rem;
    margin-top: 1rem;
  }

  .btn-primary {
    background-color: #3b82f6;
    border: none;
  }

  .btn-primary:hover {
    background-color: #2563eb;
  }

  .btn-danger {
    background-color: #ef4444;
    border: none;
  }

  .btn-danger:hover {
    background-color: #dc2626;
  }

  .alert-success {
    background-color: #d1fae5;
    color: #065f46;
    border-left: 5px solid #10b981;
    border-radius: 6px;
    padding: 1rem;
    margin-bottom: 1.5rem;
  }

  .form-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 0.75rem;
    margin-top: 1rem;
  }

  .section-title {
    margin-bottom: 1rem;
    color: #1f2937;
  }
</style>

<!-- Konten Halaman -->
<div class="container mt-5">
  <div class="table-container">
    <h2>📊 Hasil Nilai Preferensi</h2>

    <?php if (session()->getFlashdata('success')): ?>
      <div class="alert alert-success">
        <?= session()->getFlashdata('success'); ?>
      </div>
    <?php endif; ?>

    <div class="table-responsive">
      <table class="table table-bordered table-striped mt-3">
        <thead>
          <tr>
            <th>No</th>
            <th>Kode Daging</th>
            <th>Jenis Daging</th>
            <th>Nilai Preferensi</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; foreach ($preferensi as $p): ?>
            <tr>
              <td><?= $no++; ?></td>
              <td><?= esc($p['kode_daging']); ?></td>
              <td><?= esc($p['jenis_daging']); ?></td>
              <td><?= number_format($p['nilai_preferensi'], 4); ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="form-buttons">
      <form action="<?= base_url('preferensi/hitung'); ?>" method="post">
        <?= csrf_field(); ?>
        <button type="submit" class="btn btn-primary">Hitung Normalisasi</button>
      </form>

      <form action="<?= base_url('preferensi/hapussemua'); ?>" method="post" onsubmit="return confirm('Yakin ingin menghapus semua data?');">
        <?= csrf_field(); ?>
        <button type="submit" class="btn btn-danger">Hapus Semua</button>
      </form>
    </div>
  </div>

  <?php if (!empty($preferensi)): ?>
    <?php
      $ranking = $preferensi;
      usort($ranking, function($a, $b) {
        return $b['nilai_preferensi'] <=> $a['nilai_preferensi'];
      });
    ?>
    <div class="table-container">
      <h3 class="section-title">🏅 Ranking Alternatif</h3>
      <div class="table-responsive">
        <table class="table table-bordered table-striped mt-2">
          <thead>
            <tr>
              <th>No</th>
              <th>Jenis Daging</th>
              <th>Ranking</th>
            </tr>
          </thead>
          <tbody>
            <?php $rank = 1; foreach ($ranking as $r): ?>
              <tr>
                <td><?= $rank; ?></td>
                <td><?= esc($r['jenis_daging']); ?></td>
                <td><?= $rank; ?></td>
              </tr>
              <?php $rank++; ?>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php endif; ?>
</div>

<?= $this->endSection(); ?>
