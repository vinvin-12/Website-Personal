<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?= esc($title) ?></title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            margin: 20px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        table, th, td {
            border: 1px solid #444;
        }
        th, td {
            padding: 8px;
            text-align: center;
        }
        .terpilih {
            background-color: #d4edda;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h2>Laporan Data Daging Ayam Terbaik</h2>

    <?php if (!empty($preferensi)): ?>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Daging</th>
                <th>Jenis Daging</th>
                <th>Nilai Preferensi</th>
                <th>Ranking</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <tr class="terpilih">
                <td>1</td>
                <td><?= esc($preferensi['kode_daging']) ?></td>
                <td><?= esc($preferensi['jenis_daging']) ?></td>
                <td><?= number_format($preferensi['nilai_preferensi'], 4) ?></td>
                <td>1</td>
                <td>Terbaik</td>
            </tr>
        </tbody>
    </table>
    <?php else: ?>
        <p>Data tidak tersedia.</p>
    <?php endif; ?>

    <p style="margin-top: 20px; font-size: 11px;">Dicetak pada: <?= date('d-m-Y H:i:s') ?></p>
</body>
</html>
