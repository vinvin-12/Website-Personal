<?php

namespace App\Models;

use CodeIgniter\Model;

class Nilaiakhirmodel extends Model
{
    protected $table = 'nilai_akhir';
    protected $primaryKey = 'id_nilaiakhir';
    protected $allowedFields = ['id_daging', 'id_kriteria', 'id_utility', 'nilai_akhir'];

    public function hapusSemua()
    {
        $this->where('id_nilaiakhir IS NOT NULL')->delete();
    }

    /**
     * Ambil data nilai akhir dengan detail supplier & kriteria,
     * tanpa diurutkan (atau bisa diurutkan berdasarkan kode_sup).
     * Data di-group dan diakumulasi total nilai per supplier,
     * tapi hasilnya urut berdasarkan kode_sup agar tampilan tetap rapih.
     */
    public function getNilaiAkhirGrouped()
{
    $data = $this->select('nilai_akhir.*, data_daging.id_daging, data_daging.kode_daging, data_daging.jenis_daging, kriteria.id_kriteria, kriteria.nama_kriteria')
        ->join('data_daging', 'data_daging.id_daging = nilai_akhir.id_daging')
        ->join('kriteria', 'kriteria.id_kriteria = nilai_akhir.id_kriteria')
        ->orderBy('data_daging.kode_daging', 'ASC')
        ->findAll();

    $result = [];
    foreach ($data as $row) {
        $id_daging = $row['id_daging'];
        $id_kriteria = $row['id_kriteria'];

        if (!isset($result[$id_daging])) {
            $result[$id_daging] = [
                'id_daging' => $id_daging,  // Penting untuk mapping ranking
                'kode_daging' => $row['kode_daging'],
                'jenis_daging' => $row['jenis_daging'],
                'nilai' => [],
                'total' => 0
            ];
        }

        $result[$id_daging]['nilai'][$id_kriteria] = $row['nilai_akhir'];
        $result[$id_daging]['total'] += $row['nilai_akhir'];
    }

    return array_values($result);
}

    public function getRanking()
{
    return $this->db->table('nilai_akhir')
        ->select('data_daging.jenis_daging, SUM(nilai_akhir.nilai_akhir) as total_nilai')
        ->join('data_daging', 'data_daging.id_daging = nilai_akhir.id_daging')
        ->groupBy('nilai_akhir.id_daging')
        ->orderBy('total_nilai', 'DESC')
        ->get()
        ->getResultArray();
}

}
