<?php

namespace App\Models;

use CodeIgniter\Model;

class TopsisPreferensiModel extends Model
{
    protected $table = 'topsis_preferensi';
    protected $primaryKey = 'id_preferensi';
    protected $allowedFields = [
        'id_daging',
        'id_kriteria',
        'id_ideal',
        'nilai_preferensi'
    ];

    protected $useTimestamps = false;

    // (Optional) Ambil preferensi dengan join detail
    public function getWithDetails()
    {
        return $this->db->table($this->table)
            ->select('topsis_preferensi.*, data_daging.jenis_daging, kriteria.nama_kriteria')
            ->join('data_daging', 'data_daging.id_daging = topsis_preferensi.id_daging')
            ->join('kriteria', 'kriteria.id_kriteria = topsis_preferensi.id_kriteria')
            ->orderBy('nilai_preferensi', 'DESC')
            ->get()
            ->getResultArray();
    }
}
