<?php

namespace App\Models;

use CodeIgniter\Model;

class TopsisNormalisasiModel extends Model
{
    protected $table = 'topsis_normalisasi';
    protected $primaryKey = 'id_normalisasi';
    protected $allowedFields = ['id_daging', 'id_kriteria', 'id_penilaian', 'nilai_normalisasi'];

    public function getNormalisasiWithDetail()
    {
        return $this->select('topsis_normalisasi.*, data_daging.kode_daging, data_daging.jenis_daging, kriteria.nama_kriteria')
                    ->join('data_daging', 'data_daging.id_daging = topsis_normalisasi.id_daging')
                    ->join('kriteria', 'kriteria.id_kriteria = topsis_normalisasi.id_kriteria')
                    ->findAll();
    }
}
