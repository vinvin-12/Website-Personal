<?php

namespace App\Models;

use CodeIgniter\Model;

class TopsisIdealModel extends Model
{
    protected $table = 'topsis_ideal';
    protected $primaryKey = 'id_ideal';

    protected $allowedFields = [
        'id_daging',
        'id_kriteria',
        'id_terbobot',
        'ideal_positif',
        'ideal_negatif'
    ];

    public function getIdealWithDetailGrouped()
    {
        return $this->db->table('topsis_ideal ti')
            ->select('
                ti.id_kriteria,
                k.nama_kriteria,
                MAX(ti.ideal_positif) as ideal_positif,
                MIN(ti.ideal_negatif) as ideal_negatif
            ')
            ->join('kriteria k', 'k.id_kriteria = ti.id_kriteria')
            ->groupBy('ti.id_kriteria, k.nama_kriteria')
            ->get()
            ->getResultArray();
    }

    public function getNilaiIdealByKriteria()
    {
        return $this->db->table('topsis_terbobot tt')
            ->select('
                tt.id_kriteria,
                k.jenis_kriteria,
                MAX(tt.nilai_terbobot) as max_terbobot,
                MIN(tt.nilai_terbobot) as min_terbobot
            ')
            ->join('kriteria k', 'k.id_kriteria = tt.id_kriteria')
            ->groupBy('tt.id_kriteria, k.jenis_kriteria')
            ->get()
            ->getResultArray();
    }
}
