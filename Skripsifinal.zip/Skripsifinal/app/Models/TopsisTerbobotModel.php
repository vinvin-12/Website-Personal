<?php

namespace App\Models;

use CodeIgniter\Model;

class TopsisTerbobotModel extends Model
{
    protected $table = 'topsis_terbobot';
    protected $primaryKey = 'id_terbobot';
    protected $allowedFields = ['id_daging', 'id_kriteria', 'id_normalisasi', 'nilai_terbobot'];

    /**
     * Mengambil data lengkap terbobot beserta kode daging, jenis, dan nama kriteria
     */
    public function getTerbobotWithDetail()
    {
        return $this->select('
                        topsis_terbobot.*,
                        data_daging.kode_daging,
                        data_daging.jenis_daging,
                        kriteria.nama_kriteria,
                        bobot.nilai_bobot,
                        topsis_normalisasi.nilai_normalisasi
                    ')
                    ->join('data_daging', 'data_daging.id_daging = topsis_terbobot.id_daging')
                    ->join('kriteria', 'kriteria.id_kriteria = topsis_terbobot.id_kriteria')
                    ->join('bobot', 'bobot.id_bobot = kriteria.id_bobot')
                    ->join('topsis_normalisasi', 'topsis_normalisasi.id_normalisasi = topsis_terbobot.id_normalisasi')
                    ->findAll();
    }

    /**
     * Hitung dan simpan matriks terbobot (r_ij * w_j)
     */
    public function hitungDanSimpanTerbobot()
    {
        // Ambil semua data normalisasi + kriteria + bobot
        $db = \Config\Database::connect();
        $builder = $db->table('topsis_normalisasi');
        $builder->select('
            topsis_normalisasi.id_normalisasi,
            topsis_normalisasi.id_daging,
            topsis_normalisasi.id_kriteria,
            topsis_normalisasi.nilai_normalisasi,
            bobot.nilai_bobot
        ');
        $builder->join('kriteria', 'kriteria.id_kriteria = topsis_normalisasi.id_kriteria');
        $builder->join('bobot', 'bobot.id_bobot = kriteria.id_bobot');
        $data = $builder->get()->getResultArray();

        // Kosongkan tabel sebelum insert ulang (opsional)
        $this->truncate();

        // Loop dan simpan hasil terbobot
        foreach ($data as $row) {
            $nilai_terbobot = $row['nilai_normalisasi'] * $row['nilai_bobot'];

            $this->insert([
                'id_daging'        => $row['id_daging'],
                'id_kriteria'      => $row['id_kriteria'],
                'id_normalisasi'   => $row['id_normalisasi'],
                'nilai_terbobot'   => $nilai_terbobot
            ]);
        }
    }
}
