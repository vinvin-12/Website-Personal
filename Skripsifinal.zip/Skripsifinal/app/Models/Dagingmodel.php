<?php

namespace App\Models;

use CodeIgniter\Model;

class Dagingmodel extends Model
{
    protected $table = 'data_daging';
    protected $primaryKey = 'id_daging';
    protected $useAutoIncrement = false;
    protected $useTimestamps = true;
    protected $allowedFields = ['id_daging','kode_daging', 'jenis_daging'];

    public function getsupplier($id_daging)
    {
        return $this->where(['id_daging' => $id_daging])->first();
    }
    public function getActiveDaging()
    {
        // Ambil semua supplier (karena tidak ada kolom status)
        return $this->findAll();
    }
}
