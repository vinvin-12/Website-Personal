<?php

namespace App\Controllers;

use App\Models\TopsisIdealModel;
use App\Models\TopsisTerbobotModel;
use App\Models\Kriteriamodel;

class Ideal extends BaseController
{
    protected $idealModel;
    protected $terbobotModel;
    protected $kriteriaModel;

    public function __construct()
    {
        $this->idealModel = new TopsisIdealModel();
        $this->terbobotModel = new TopsisTerbobotModel();
        $this->kriteriaModel = new Kriteriamodel();
    }

    public function index()
    {
        $idealRaw = $this->idealModel->getIdealWithDetailGrouped();

        $ideal = [];
        $kriteria = [];

        foreach ($idealRaw as $row) {
            $id_kriteria = $row['id_kriteria'];

            $ideal[] = [
                'id_kriteria'    => $id_kriteria,
                'nama_kriteria'  => $row['nama_kriteria'],
                'ideal_positif'  => $row['ideal_positif'],
                'ideal_negatif'  => $row['ideal_negatif'],
            ];

            $kriteria[$id_kriteria] = $row['nama_kriteria'];
        }

        return view('ideal/index', [
            'title' => 'Solusi Ideal',
            'ideal' => $ideal,
            'kriteria' => $kriteria
        ]);
    }

    public function hitung()
    {
        // Kosongkan tabel solusi ideal
        $this->idealModel->emptyTable();

        // Ambil semua data terbobot
        $terbobotData = $this->terbobotModel->findAll();
        $kriteriaList = $this->kriteriaModel->findAll();

        // Kelompokkan nilai terbobot per kriteria
        $grouped = []; // [id_kriteria => [id_daging => [nilai_terbobot, id_terbobot]]]
        foreach ($terbobotData as $row) {
            $grouped[$row['id_kriteria']][$row['id_daging']] = [
                'nilai' => $row['nilai_terbobot'],
                'id_terbobot' => $row['id_terbobot']
            ];
        }

        // Hitung ideal positif dan negatif untuk setiap kriteria
        foreach ($kriteriaList as $kriteria) {
            $id_kriteria = $kriteria['id_kriteria'];
            $jenis = strtolower($kriteria['jenis_kriteria']);

            if (!isset($grouped[$id_kriteria])) continue;

            $nilaiArray = array_column($grouped[$id_kriteria], 'nilai', 'id_daging');

            if ($jenis === 'benefit') {
                $ideal_positif = max($nilaiArray);
                $ideal_negatif = min($nilaiArray);
            } else {
                $ideal_positif = min($nilaiArray);
                $ideal_negatif = max($nilaiArray);
            }

            foreach ($grouped[$id_kriteria] as $id_daging => $data) {
                $this->idealModel->insert([
                    'id_daging'      => $id_daging,
                    'id_kriteria'    => $id_kriteria,
                    'id_terbobot'    => $data['id_terbobot'],
                    'ideal_positif'  => $ideal_positif,
                    'ideal_negatif'  => $ideal_negatif
                ]);
            }
        }

        return redirect()->to('/ideal')->with('success', 'Solusi ideal berhasil dihitung.');
    }

    public function hapussemua()
    {
        $this->idealModel->emptyTable();
        return redirect()->to('/ideal')->with('success', 'Semua data solusi ideal berhasil dihapus.');
    }
}
