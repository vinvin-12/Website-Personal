<?php

namespace App\Controllers;

use App\Models\Kriteriamodel;
use App\Models\Dagingmodel;
use App\Models\Nilaiakhirmodel;
use App\Models\Parametermodel;
use App\Models\TopsisPreferensiModel; // Tambahan

class Dashboard extends BaseController
{
    public function index()
    {
        if (!session()->get('logged_in')) {
            return view('dashboard/umum');
        }

        // Khusus admin
        if (session()->get('role') !== 'admin') {
            return redirect()->to('/dashboard/indexowner');
        }

        $Dagingmodel = new Dagingmodel();
        $totaldaging = $Dagingmodel->countAll();

        $kriteriaModel = new Kriteriamodel();
        $totalKriteria = $kriteriaModel->countAll();

        $Parametermodel = new Parametermodel();
        $totalParameter = $Parametermodel->countAll();

        $nilaiAkhirModel = new Nilaiakhirmodel();
        $ranking = $nilaiAkhirModel->getRanking();

        $dagingTerbaik = (!empty($ranking)) ? $ranking[0]['jenis_daging'] : 'Belum Ada';

        $data = [
            'title' => 'Sistem Pemilihan Daging Terbaik',
            'totalKriteria' => $totalKriteria,
            'totaldaging' => $totaldaging,
            'totalParameter' => $totalParameter,
            'dagingTerbaik' => $dagingTerbaik,
            'ranking' => $ranking,
        ];

        return view('dashboard/admin', $data);
    }

    public function indexowner()
    {
        $nilaiAkhirModel = new Nilaiakhirmodel();
        $ranking = $nilaiAkhirModel->getRanking();

        $dagingNames = array_map(fn($r) => $r['jenis_daging'], $ranking);
        $dagingScores = array_map(fn($r) => (float)$r['total_nilai'], $ranking);
        $topDaging = array_slice($ranking, 0, 3);

        // Ambil daging aktif
        $Dagingmodel = new Dagingmodel();
        $activeDaging = $Dagingmodel->getActiveDaging();

        // Ambil nilai preferensi
        $preferensiModel = new TopsisPreferensiModel();
        $preferensi = $preferensiModel
                        ->select('topsis_preferensi.*, data_daging.kode_daging, data_daging.jenis_daging')
                        ->join('data_daging', 'data_daging.id_daging = topsis_preferensi.id_daging')
                        ->orderBy('nilai_preferensi', 'DESC')
                        ->findAll();

        // KPI dummy
        $totalTransaksi = 0;
        $totalPembelian = 0;
        $persentasePengiriman = 0;

        return view('dashboard/owner', [
            'ranking' => $ranking,
            'dagingNames' => $dagingNames,
            'dagingScores' => $dagingScores,
            'topDaging' => $topDaging,
            'dagingAktif' => $activeDaging,
            'totalTransaksi' => $totalTransaksi,
            'jumlahDaging' => count($activeDaging),
            'preferensi' => $preferensi, // ✅ Dikirim ke view
        ]);
    }
}
