<?php

namespace App\Controllers;

use App\Models\Penilaianmodel;
use App\Models\Dagingmodel;
use App\Models\Kriteriamodel;
use App\Models\Parametermodel;

class Penilaian extends BaseController
{
    protected $Penilaianmodel;

    public function __construct()
    {
        $this->Penilaianmodel = new Penilaianmodel();
    }

    public function index(): string
    {
        $penilaian = $this->Penilaianmodel->getPenilaianWithDetail();

        // Mengelompokkan berdasarkan supplier dan kriteria
        $dataPenilaian = [];
        $kriteriaList = [];

        foreach ($penilaian as $p) {
            $dataPenilaian[$p['id_daging']]['jenis_daging'] = $p['jenis_daging'];
            $dataPenilaian[$p['id_daging']]['kode_daging'] = $p['kode_daging'];
            $dataPenilaian[$p['id_daging']]['nilai'][$p['id_kriteria']] = $p['nilai'];
            $kriteriaList[$p['id_kriteria']] = $p['nama_kriteria'];
        }

        $data = [
            'title' => 'Data Penilaian Daging',
            'penilaian' => $dataPenilaian,
            'kriteria' => $kriteriaList
        ];

        return view('penilaian/index', $data);
    }

    public function tambah()
    {
        $Dagingmodel = new Dagingmodel();
        $Kriteriamodel = new Kriteriamodel();
        $Parametermodel = new Parametermodel();

        $data = [
            'title' => 'Form Tambah Penilaian',
            'daging' => $Dagingmodel->findAll(),
            'kriteria' => $Kriteriamodel->findAll(),
            'parameter' => $Parametermodel->findAll()
        ];

        return view('penilaian/tambah', $data);
    }

    public function simpan()
    {
        $id_daging = $this->request->getPost('id_daging');
        $id_kriteria = $this->request->getPost('id_kriteria');       // array
        $id_parameter = $this->request->getPost('id_parameter');     // array

        // Validasi sederhana
        if (!$id_daging || !is_array($id_kriteria) || !is_array($id_parameter)) {
            return redirect()->back()->with('error', 'Data tidak valid');
        }

        // Hapus data penilaian lama untuk supplier ini agar tidak terjadi duplikasi
        $this->Penilaianmodel->where('id_daging', $id_daging)->delete();

        foreach ($id_kriteria as $i => $idk) {
            $this->Penilaianmodel->save([
                'id_daging' => $id_daging,
                'id_kriteria' => $idk,
                'id_parameter' => $id_parameter[$i]
            ]);
        }

        return redirect()->to('/penilaian')->with('success', 'Data penilaian berhasil disimpan.');
    }

    public function hapus($id_daging)
    {
        $this->Penilaianmodel->where('id_daging', $id_daging)->delete();
        return redirect()->to('/penilaian')->with('success', 'Data penilaian berhasil dihapus.');
    }

    public function edit($id_daging)
    {
        $Kriteriamodel = new Kriteriamodel();
        $Dagingmodel = new Dagingmodel();
        $Parametermodel = new Parametermodel();

        $penilaian = $this->Penilaianmodel->where('id_daging', $id_daging)->findAll();

        if (!$penilaian) {
            return redirect()->to('/penilaian')->with('error', 'Data tidak ditemukan.');
        }

         // Ambil nama supplier
    $daging = $Dagingmodel->find($id_daging);
    if (!$daging) {
        return redirect()->to('/penilaian')->with('error', 'Supplier tidak ditemukan.');
    }

        $data = [
            'title' => 'Form Ubah Penilaian Daging',
            'id_daging' => $id_daging,
            'daging' => $Dagingmodel->findAll(),
            'kriteria' => $Kriteriamodel->findAll(),
            'parameter' => $Parametermodel->findAll(),
            'penilaian' => $penilaian
        ];

        return view('penilaian/edit', $data);
    }

    public function ubah($id_daging)
    {
        $id_kriteria = $this->request->getPost('id_kriteria');
        $id_parameter = $this->request->getPost('id_parameter');

        // Validasi
        if (!$id_daging || !is_array($id_kriteria) || !is_array($id_parameter)) {
            return redirect()->back()->with('error', 'Data tidak valid');
        }

        // Hapus data lama
        $this->Penilaianmodel->where('id_daging', $id_daging)->delete();

        // Simpan data baru
        foreach ($id_kriteria as $i => $idk) {
            $this->Penilaianmodel->save([
                'id_daging' => $id_daging,
                'id_kriteria' => $idk,
                'id_parameter' => $id_parameter[$i]
            ]);
        }

        return redirect()->to('/penilaian')->with('success', 'Data penilaian berhasil diubah.');
    }
}
