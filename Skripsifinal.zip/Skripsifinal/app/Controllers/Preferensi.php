<?php

namespace App\Controllers;

use App\Models\TopsisTerbobotModel;
use App\Models\TopsisIdealModel;
use App\Models\TopsisPreferensiModel;
use App\Models\Dagingmodel;
use Dompdf\Dompdf;

class Preferensi extends BaseController
{
    protected $terbobotModel;
    protected $idealModel;
    protected $preferensiModel;
    protected $dagingModel;

    public function __construct()
    {
        $this->terbobotModel    = new TopsisTerbobotModel();
        $this->idealModel       = new TopsisIdealModel();
        $this->preferensiModel  = new TopsisPreferensiModel();
        $this->dagingModel      = new Dagingmodel();
    }

    public function index()
    {
        $role = session()->get('role');

        if ($role === 'owner') {
            return $this->indexowner();
        }

        $preferensi = $this->preferensiModel->select('topsis_preferensi.*, data_daging.kode_daging, data_daging.jenis_daging')
                            ->join('data_daging', 'data_daging.id_daging = topsis_preferensi.id_daging')
                            ->orderBy('nilai_preferensi', 'DESC')
                            ->findAll();

        return view('nilaipreferensi/index', [
            'title' => 'Hasil Nilai Preferensi',
            'preferensi' => $preferensi
        ]);
    }

    public function indexowner()
    {
        // Batasi akses hanya untuk role 'owner'
        if (session()->get('role') !== 'owner') {
            return redirect()->to('/')->with('error', 'Anda tidak memiliki akses ke halaman ini.');
        }

        $preferensi = $this->preferensiModel->select('topsis_preferensi.*, data_daging.kode_daging, data_daging.jenis_daging')
                            ->join('data_daging', 'data_daging.id_daging = topsis_preferensi.id_daging')
                            ->orderBy('nilai_preferensi', 'DESC')
                            ->findAll();

        return view('nilaipreferensi/indexowner', [
            'title' => 'Rangking Alternatif - Owner',
            'preferensi' => $preferensi
        ]);
    }

    public function hitung()
    {
        $this->preferensiModel->emptyTable();

        $terbobot = $this->terbobotModel->findAll();
        $ideal = $this->idealModel->findAll();

        $idealData = [];
        foreach ($ideal as $i) {
            $idealData[$i['id_kriteria']] = [
                'positif'  => $i['ideal_positif'],
                'negatif'  => $i['ideal_negatif'],
                'id_ideal' => $i['id_ideal']
            ];
        }

        $jarak = [];
        foreach ($terbobot as $t) {
            $id_daging   = $t['id_daging'];
            $id_kriteria = $t['id_kriteria'];
            $nilai       = $t['nilai_terbobot'];

            if (!isset($idealData[$id_kriteria])) continue;

            $idealPos = $idealData[$id_kriteria]['positif'];
            $idealNeg = $idealData[$id_kriteria]['negatif'];

            if (!isset($jarak[$id_daging])) {
                $jarak[$id_daging] = ['positif' => 0, 'negatif' => 0];
            }

            $jarak[$id_daging]['positif'] += pow($nilai - $idealPos, 2);
            $jarak[$id_daging]['negatif'] += pow($nilai - $idealNeg, 2);
        }

        foreach ($jarak as $id_daging => $d) {
            $dPlus = sqrt($d['positif']);
            $dMin  = sqrt($d['negatif']);
            $preferensi = $dMin / ($dPlus + $dMin);

            $firstKriteriaId = array_key_first($idealData);
            $id_ideal = $idealData[$firstKriteriaId]['id_ideal'];

            $this->preferensiModel->save([
                'id_daging'         => $id_daging,
                'id_kriteria'       => $firstKriteriaId,
                'id_ideal'          => $id_ideal,
                'nilai_preferensi'  => round($preferensi, 4)
            ]);
        }

        return redirect()->to('/preferensi')->with('success', 'Nilai preferensi berhasil dihitung.');
    }

    public function hapussemua()
    {
        $this->preferensiModel->emptyTable();
        return redirect()->to('/preferensi')->with('success', 'Data preferensi berhasil dihapus.');
    }

    public function cetakpdfowner()
{
    if (session()->get('role') !== 'owner') {
        return redirect()->to('/')->with('error', 'Anda tidak memiliki akses ke halaman ini.');
    }

    require_once ROOTPATH . 'vendor/autoload.php';

    $topPreferensi = $this->preferensiModel->select('topsis_preferensi.*, data_daging.kode_daging, data_daging.jenis_daging')
                            ->join('data_daging', 'data_daging.id_daging = topsis_preferensi.id_daging')
                            ->orderBy('nilai_preferensi', 'DESC')
                            ->first();

    $data = [
        'title' => 'Laporan Nilai Preferensi - Owner',
        'preferensi' => $topPreferensi
    ];

    $dompdf = new Dompdf();
    $html = view('nilaipreferensi/pdfowner', $data);
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    $dompdf->stream('Laporan_Preferensi_Terbaik.pdf', ['Attachment' => true]);
    exit;
}
}
