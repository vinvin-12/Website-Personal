<?php
namespace App\Controllers;

use App\models\usermodel;

class Auth extends BaseController
{
    public function login()
    {
        return view('auth/login');
    }

    public function lupapw()
    {
        return view('auth/lupapw');
    }

    public function ceklogin()
    {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $usermodel = new \App\models\usermodel();
        $user = $usermodel->where('username', $username)->first();

        if ($user && $user['password'] === $password) {
            session()->set([
                'id_user' => $user['id_user'],
                'nama_user' => $user['nama_user'],
                'role' => $user['role'],
                'logged_in' => true
            ]);

            return redirect()->to('/dashboard/index');
        }

        session()->setFlashdata('error', 'Username atau password salah.');
        return redirect()->to('/auth/login');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/dashboard/index');
    }
}
