<?php

namespace App\Controllers;

use App\Models\TopsisNormalisasiModel;
use App\Models\TopsisTerbobotModel;
use App\Models\Kriteriamodel;
use App\Models\Dagingmodel;

class Terbobot extends BaseController
{
    protected $normalisasiModel;
    protected $terbobotModel;
    protected $kriteriaModel;
    protected $dagingModel;

    public function __construct()
    {
        $this->normalisasiModel = new TopsisNormalisasiModel();
        $this->terbobotModel = new TopsisTerbobotModel();
        $this->kriteriaModel = new Kriteriamodel();
        $this->dagingModel = new Dagingmodel();
    }

    public function index()
    {
        $terbobot = $this->terbobotModel->getTerbobotWithDetail();
        $kriteriaList = [];

        $dataTerbobot = [];
        foreach ($terbobot as $t) {
            $dataTerbobot[$t['id_daging']]['jenis_daging'] = $t['jenis_daging'];
            $dataTerbobot[$t['id_daging']]['kode_daging'] = $t['kode_daging'];
            $dataTerbobot[$t['id_daging']]['nilai'][$t['id_kriteria']] = $t['nilai_terbobot'];
            $kriteriaList[$t['id_kriteria']] = $t['nama_kriteria'];
        }

        $data = [
            'title'     => 'Normalisasi Matriks Terbobot',
            'terbobot'  => $dataTerbobot,
            'kriteria'  => $kriteriaList,
        ];

        return view('normalisasiterbobot/index', $data);
    }

    public function hitung()
    {
        // Ambil semua data normalisasi dan bobot dari kriteria
        $db = \Config\Database::connect();
        $builder = $db->table('topsis_normalisasi');
        $builder->select('
            topsis_normalisasi.id_normalisasi,
            topsis_normalisasi.id_daging,
            topsis_normalisasi.id_kriteria,
            topsis_normalisasi.nilai_normalisasi,
            bobot.nilai_bobot
        ');
        $builder->join('kriteria', 'kriteria.id_kriteria = topsis_normalisasi.id_kriteria');
        $builder->join('bobot', 'bobot.id_bobot = kriteria.id_bobot');
        $normalisasiData = $builder->get()->getResultArray();

        // Kosongkan data sebelumnya
        $this->terbobotModel->emptyTable();

        // Simpan perhitungan terbobot
        foreach ($normalisasiData as $n) {
            $nilai_terbobot = $n['nilai_normalisasi'] * $n['nilai_bobot'];

            $this->terbobotModel->insert([
                'id_daging'        => $n['id_daging'],
                'id_kriteria'      => $n['id_kriteria'],
                'id_normalisasi'   => $n['id_normalisasi'],
                'nilai_terbobot'   => round($nilai_terbobot, 4)
            ]);
        }

        return redirect()->to('/terbobot')->with('success', 'Matriks terbobot berhasil dihitung.');
    }

    public function hapussemua()
    {
        $this->terbobotModel->emptyTable();
        return redirect()->to('/terbobot')->with('success', 'Semua data terbobot berhasil dihapus.');
    }
}
