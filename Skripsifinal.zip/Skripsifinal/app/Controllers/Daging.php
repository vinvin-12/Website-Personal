<?php

namespace App\Controllers;

use App\Models\Dagingmodel;

class Daging extends BaseController
{
    protected $Dagingmodel;

    public function __construct()
    {
        $this->Dagingmodel = new Dagingmodel();
    }

    public function index(): string
    {
        $data = [
            'title' => 'Daftar Nama Daging',
            'daging' => $this->Dagingmodel->findAll()
        ];
        return view('daging/index', $data);
    }

    public function tambah()
    {
        return view('daging/tambah', ['title' => 'Form Tambah Data Daging Ayam']);
    }

    public function simpan()
    {
        $this->Dagingmodel->save([
            'id_daging' => $this->request->getVar('id_daging'),
            'kode_daging' => $this->request->getVar('kode_daging'),
            'jenis_daging' => $this->request->getVar('jenis_daging'),
        ]);
        return redirect()->to('/daging')->with('success', 'Data berhasil ditambahkan.');
    }

    public function hapus($id_daging)
    {
        $daging = $this->Dagingmodel->find($id_daging);

        if ($daging) {
            $this->Dagingmodel->delete($id_daging);
            return redirect()->to('/daging')->with('success', 'Data berhasil dihapus.');
        } else {
            return redirect()->to('/daging')->with('error', 'Data tidak ditemukan.');
        }
    }

    public function edit($id_daging)
    {
        $daging = $this->Dagingmodel->find($id_daging);

        if (!$daging) {
            return redirect()->to('/daging')->with('error', 'Data tidak ditemukan.');
        }

        $data = [
            'title' => 'Form Ubah Data Daging',
            'daging' => $daging
        ];
        return view('daging/edit', $data);
    }

    public function ubah($id_daging)
    {
        $this->Dagingmodel->save([
            'id_daging' => $id_daging,
            'kode_daging' => $this->request->getVar('kode_daging'),
            'jenis_daging' => $this->request->getVar('jenis_daging'),
        ]);
        return redirect()->to('/daging')->with('success', 'Data daging berhasil diubah.');
    }
}
