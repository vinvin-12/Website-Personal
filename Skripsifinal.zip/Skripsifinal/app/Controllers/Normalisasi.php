<?php

namespace App\Controllers;

use App\Models\TopsisNormalisasiModel;
use App\Models\Penilaianmodel;
use App\Models\Dagingmodel;
use App\Models\Kriteriamodel;

class Normalisasi extends BaseController
{
    protected $normalisasiModel;
    protected $penilaianModel;
    protected $dagingModel;
    protected $kriteriaModel;

    public function __construct()
    {
        $this->normalisasiModel = new TopsisNormalisasiModel();
        $this->penilaianModel = new Penilaianmodel();
        $this->dagingModel = new Dagingmodel();
        $this->kriteriaModel = new Kriteriamodel();
    }

    public function index()
{
    $normalisasi = $this->normalisasiModel->getNormalisasiWithDetail(); // gunakan relasi join
    $kriteriaList = [];

    $dataNormalisasi = [];

    foreach ($normalisasi as $n) {
        $dataNormalisasi[$n['id_daging']]['jenis_daging'] = $n['jenis_daging'];
        $dataNormalisasi[$n['id_daging']]['kode_daging'] = $n['kode_daging'];
        $dataNormalisasi[$n['id_daging']]['nilai'][$n['id_kriteria']] = $n['nilai_normalisasi'];
        $kriteriaList[$n['id_kriteria']] = $n['nama_kriteria'];
    }

    $data = [
        'title' => 'Normalisasi Matriks',
        'normalisasi' => $dataNormalisasi,
        'kriteria' => $kriteriaList,
    ];

    return view('normalisasi/index', $data);
}

    public function hitung()
    {
        $penilaian = $this->penilaianModel->getPenilaianWithDetail();

        // Hitung pembagi akar kuadrat untuk normalisasi
        $pembagi = [];
        foreach ($penilaian as $p) {
            $id_kriteria = $p['id_kriteria'];
            $pembagi[$id_kriteria][] = pow($p['nilai'], 2);
        }

        $akarPembagi = [];
        foreach ($pembagi as $id_kriteria => $nilai) {
            $akarPembagi[$id_kriteria] = sqrt(array_sum($nilai));
        }

        $this->normalisasiModel->emptyTable();

        // Hitung normalisasi
        foreach ($penilaian as $p) {
            $nilaiNormalisasi = $p['nilai'] / $akarPembagi[$p['id_kriteria']];

            $this->normalisasiModel->save([
                'id_daging' => $p['id_daging'],
                'id_kriteria' => $p['id_kriteria'],
                'id_penilaian' => $p['id_penilaian'],
                'nilai_normalisasi' => round($nilaiNormalisasi, 4),
            ]);
        }
        
        return redirect()->to('/normalisasi')->with('success', 'Normalisasi berhasil dihitung.');
    }
 public function hapus($id_normalisasi)
    {
        $this->normalisasiModel->delete($id_normalisasi);
        return redirect()->to('/normalisasi')->with('success', 'Data normalisasi berhasil dihapus.');
    }

    public function hapussemua()
{
    $this->normalisasiModel->emptyTable();
    return redirect()->to('/normalisasi')->with('success', 'Semua data normalisasi berhasil dihapus.');
}
}
