<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'dashboard::index');
$routes->get('/normalisasi', 'Normalisasi::index');
$routes->get('/normalisasi/hitung', 'Normalisasi::hitung');
$routes->get('/terbobot', 'Terbobot::index');
$routes->get('/terbobot/hitung', 'Terbobot::hitung');
$routes->get('/ideal', 'Ideal::index');
$routes->get('/ideal/hitung', 'Ideal::hitung');
$routes->get('/daging/hapus/(:segment)', 'Daging::hapus/$1');
$routes->get('/daging/edit/(:segment)', 'Daging::edit/$1');
$routes->put('/daging/ubah/(:segment)', 'Daging::ubah/$1');
$routes->get('/bobot/hapus/(:segment)', 'bobot::hapus/$1');
$routes->get('/bobot/edit/(:segment)', 'bobot::edit/$1');
$routes->put('/bobot/ubah/(:segment)', 'bobot::ubah/$1');
$routes->get('/kriteria/edit/(:segment)', 'kriteria::edit/$1');
$routes->put('/kriteria/ubah/(:segment)', 'kriteria::ubah/$1');
$routes->put('/parameter/edit/(:segment)', 'parameter::edit/$1');
$routes->put('/parameter/ubah/(:segment)', 'parameter::ubah/$1');
$routes->put('/penilaian/edit/(:segment)', 'penilaian::edit/$1');
$routes->put('/penilaian/ubah/(:segment)', 'penilaian::ubah/$1');
$routes->get('/utility/hitung', 'Utility::hitung');  
$routes->post('utility/hapussemua', 'Utility::hapussemua');
$routes->setAutoRoute(true); 


